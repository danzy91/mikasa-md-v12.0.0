const fetch = require('node-fetch');
const cheerio = require('cheerio');
const moment = require('moment'); // pastikan sudah install: npm install moment

exports.default = {
  names: ['Jadwal KAI'],
  tags: ['kereta'],
  command: ['ka', 'kai'],
  start: async (m, { conn, text, prefix, command }) => {
    let args = text.trim().split(/\s+/);
    if (args.length < 3) {
      return m.reply(`Masukkan asal, tujuan, tanggal, dan opsional waktu!\nContoh:\n${prefix}${command} bdg sby hariini\n${prefix}${command} bdg sby 20-04 06:00`);
    }

    let [from, to, rawTanggal, minTime] = args;

    const kotaAlias = {
      bdg: 'bandung', sby: 'surabaya', jkt: 'jakarta',
      smg: 'semarang', yk: 'yogyakarta', mlg: 'malang',
      solo: 'solo', cpn: 'cirebon'
    };

    from = kotaAlias[from] || from;
    to = kotaAlias[to] || to;

    // Tanggal fleksibel
    let tanggal = '';
    if (rawTanggal === 'hariini' || rawTanggal === 'today') {
      tanggal = moment().format('YYYY-MM-DD');
    } else if (rawTanggal === 'besok') {
      tanggal = moment().add(1, 'days').format('YYYY-MM-DD');
    } else if (/^\d{2}-\d{2}$/.test(rawTanggal)) {
      tanggal = moment(`${moment().year()}-${rawTanggal}`, 'YYYY-DD-MM').format('YYYY-MM-DD');
    } else {
      tanggal = rawTanggal;
    }

    if (!tanggal.match(/\d{4}-\d{2}-\d{2}/)) return m.reply('Tanggal tidak valid! Format: YYYY-MM-DD');

    const url = `https://en.keretaapi.info/?dari=${from}&ke=${to}&tanggal=${tanggal}`;
    try {
      const res = await fetch(url);
      const html = await res.text();
      const $ = cheerio.load(html);

      let hasil = [];
      $('table#tjadwal tr').each((i, el) => {
        const td = $(el).find('td');
        if (td.length >= 5) {
          const nama = td.eq(0).text().trim();
          const berangkat = td.eq(1).text().trim();
          const tiba = td.eq(2).text().trim();
          const durasi = td.eq(3).text().trim();
          const kelas = td.eq(4).text().trim();

          if (minTime && berangkat < minTime) return;
          hasil.push(`🚆 *${nama}*\n🕒 ${berangkat} - ${tiba} | ⏱️ ${durasi}\n🎟️ ${kelas}`);
        }
      });

      if (hasil.length === 0) return m.reply('Jadwal tidak ditemukan atau tidak ada kereta sesuai waktu.');

      await conn.sendMessage(m.chat, {
        text: `*Jadwal Kereta: ${from.toUpperCase()} → ${to.toUpperCase()} (${tanggal})*\n\n${hasil.slice(0, 5).join('\n━━━━━━━━━━━━━━━\n\n')}`,
        contextInfo: {
          externalAdReply: {
            title: 'Jadwal Kereta Hari Ini',
            body: `Dari ${from} ke ${to}`,
            thumbnailUrl: 'https://i.ibb.co/KmnrPvM/kereta.jpg',
            sourceUrl: url,
            mediaType: 1,
            renderLargerThumbnail: false,
            showAdAttribution: true
          }
        }
      }, { quoted: m });

    } catch (e) {
      console.error(e);
      m.reply('Gagal mengambil jadwal. Coba lagi nanti.');
    }
  },
  limit: false,
  type: 'forward'
}