exports.default = {
  names: ['BANTUAN PELAJAR'],
  tags: ['rumusmtk','mtk'],
  command: ['rumusmtk','mtk'],
  start: async (m, {
    conn,
    text,
    prefix,
    command,
    User,
    Format
  }) => {
    const rumus = {
      aljabar: {
        nama: "Aljabar",
        pengertian: "Aljabar adalah cabang matematika yang menggunakan simbol dan huruf untuk mewakili bilangan dan operasi matematika.",
        rumus: [
          "a(x + y) = ax + ay",
          "(x + y)^2 = x^2 + 2xy + y^2",
          "(x - y)^2 = x^2 - 2xy + y^2",
          "(x + y)(x - y) = x^2 - y^2"
        ]
      },
      phytagoras: {
        nama: "Teorema Pythagoras",
        pengertian: "Teorema Pythagoras menyatakan bahwa dalam segitiga siku-siku, kuadrat sisi miring (c) sama dengan jumlah kuadrat kedua sisi lainnya (a dan b).",
        rumus: [
          "c² = a² + b²",
          "a = √(c² - b²)",
          "b = √(c² - a²)"
        ]
      },
      luas_persegi: {
        nama: "Luas Persegi",
        pengertian: "Luas persegi dihitung dengan mengalikan panjang sisi dengan dirinya sendiri.",
        rumus: ["L = s × s"]
      }
    }

    const input = text.toLowerCase().trim();
    if (!input) {
      let list = Object.keys(rumus).map(x => `• ${x}`).join('\n');
      return m.reply(`Contoh penggunaan: *.mtk aljabar*\n\nTopik tersedia:\n${list}`);
    }

    const data = rumus[input];
    if (!data) return m.reply("Topik tidak ditemukan. Gunakan *.mtk* untuk melihat daftar.");

    // Gambar diagram batang dengan QuickChart API
    const chartURL = `https://quickchart.io/chart?c=${encodeURIComponent(JSON.stringify({
      type: "bar",
      data: {
        labels: ["2022", "2023", "2024"],
        datasets: [{
          label: "Contoh Data",
          data: [10, 15, 20],
          backgroundColor: ["#36A2EB", "#FF6384", "#FFCE56"]
        }]
      },
      options: {
        title: {
          display: true,
          text: "Diagram Batang (Contoh)"
        }
      }
    }))}`;

    // Format hasil
    let caption = `*${data.nama}*\n\n*Pengertian:*\n${data.pengertian}\n\n*Rumus:*\n${data.rumus.map((x, i) => `${i + 1}. ${x}`).join('\n')}`;
    m.react('✅')
    await conn.sendMessage(m.chat, {
      image: { url: chartURL },
      caption
    }, { quoted: m });
  },
  limit: false
}