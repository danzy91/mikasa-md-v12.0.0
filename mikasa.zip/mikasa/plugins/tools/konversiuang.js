exports.default = {
  names: ['Tools'],
  tags: ['konversi'],
  command: ['konversi'],
  start: async (m, { conn, text, prefix }) => {
    if (!text) return m.reply(`Contoh: *${prefix}currency 100 USD to IDR*\nAtau: *${prefix}currency 500 JPY > EUR*`);

    try {
      // Parse input
      const pattern = /([0-9.,]+)\s*([a-zA-Z]{3})\s*(to|>|in)?\s*([a-zA-Z]{3})?/i;
      const match = text.match(pattern);
      
      if (!match) throw new Error('Format salah! Contoh: 100 USD to IDR');
      
      const amount = parseFloat(match[1].replace(',', ''));
      const from = match[2].toUpperCase();
      const to = (match[4] || 'IDR').toUpperCase(); // Default to IDR

      // Get exchange rates
      const apiUrl = `https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/${from.toLowerCase()}.json`;
      const response = await fetch(apiUrl);
      
      if (!response.ok) throw new Error(`Mata uang ${from} tidak ditemukan atau API error`);

      const { date, [from.toLowerCase()]: rates } = await response.json();
      
      if (!rates[to.toLowerCase()]) throw new Error(`Tidak ada rate untuk ${to}`);

      // Calculate conversion
      const rate = rates[to.toLowerCase()];
      const result = (amount * rate).toLocaleString('en', { maximumFractionDigits: 2 });
      const formattedAmount = amount.toLocaleString('en', { maximumFractionDigits: 2 });

      // Format response
      const lastUpdate = new Date(date).toLocaleString('id-ID');
      const currenciesList = `🔍 *Daftar Kode Mata Uang*:\nUSD, EUR, IDR, JPY, GBP, CNY, SGD, AUD, dll\n(Lihat lengkap: https://www.exchangerate-api.com/docs/supported-currencies)`;

      const message = `💱 *Konversi Mata Uang*\n\n` +
                     `💵 ${formattedAmount} ${from} = *${result} ${to}*\n` +
                     `📊 Rate: 1 ${from} = ${rate.toFixed(6)} ${to}\n` +
                     `⏰ Update: ${lastUpdate}\n\n` +
                     `${currenciesList}`;

      conn.sendMessage(m.chat, { 
        text: message,
        contextInfo: {
          externalAdReply: {
            title: `💵 ${from} → ${to} Converter`,
            body: `Rate: ${rate.toFixed(2)} • Update: ${lastUpdate}`,
            thumbnail: await (await fetch('https://i.imgur.com/f7R7Tzr.png')).arrayBuffer(),
            sourceUrl: 'https://github.com/fawazahmed0/currency-api'
          }
        }
      });

    } catch (error) {
      m.reply(`🚨 Error: ${error.message}\n\nContoh penggunaan:\n*${prefix}currency 10 USD to IDR*\n*${prefix}konversi 500 JPY > EUR*`);
    }
  },
  limit: false,
  premium: false
};