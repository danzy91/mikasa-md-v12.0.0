const axios = require('axios');

exports.default = {
  names: ['PANDUAN PELAJAR'],
  tags: ['sejarah'],
  command: ['sejarah'],
  start: async (m, { conn, text, prefix, command }) => {
    if (!text) return m.reply(`Contoh penggunaan: ${prefix + command} [judul sejarah]`);

    try {
      const query = encodeURIComponent(text);
      const url = `https://id.wikipedia.org/api/rest_v1/page/summary/${query}`;
      const response = await axios.get(url);
      const data = response.data;

      if (data.type === 'disambiguation') {
        return m.reply(`Topik "${text}" memiliki beberapa arti. Silakan perjelas pencarian Anda.`);
      }

      const title = data.title || 'Judul tidak ditemukan';
      const extract = data.extract || 'Deskripsi tidak tersedia.';
      const thumbnail = data.thumbnail?.source || null;
      const message = `📚 *${title}*\n\n${extract}`;

      if (thumbnail) {
        // kirim sebagai gambar
        await conn.sendMessage(m.chat, {
          image: { url: thumbnail },
          caption: message
        }, { quoted: m });
      } else {
        m.reply(message);
      }
    } catch (err) {
      console.error(err);
      m.reply('Terjadi kesalahan saat mengambil data sejarah. Coba judul lain.');
    }
  },
  limit: false,
  register: true
};