const fetch = require('node-fetch');

exports.default = {
  names: ['BANTUAN PELAJAR'],
  tags: ['rumusipa'],
  command: ['rumusipa'],
  start: async (m, { conn, text, prefix }) => {

    const thumbnailUrl = 'https://i.ibb.co/3kV0dNV/ipa-logo.jpg';
    const semuaRumus = {
      '1. Mekanika': {
        'Gaya (F=ma)': 'F = m × a\nContoh: m=2kg, a=3m/s² → F=6N',
        'Energi Kinetik': 'Ek = ½ × m × v²\nContoh: m=5kg, v=10m/s → Ek=250J'
      },
      '2. Listrik': {
        'Hukum Ohm': 'V = I × R\nContoh: I=2A, R=3Ω → V=6V',
        'Daya Listrik': 'P = V × I\nContoh: V=12V, I=0.5A → P=6W'
      },
      '3. Termodinamika': {
        'Gas Ideal': 'PV = nRT\nContoh: P=1atm, V=22.4L → n=1mol (STP)',
        'Kalor': 'Q = m × c × ΔT\nContoh: m=1kg, ΔT=50°C, c=4200 → Q=210kJ'
      },
      '4. Tekanan': {
        'Tekanan Zat Cair': 'P = ρ × g × h\nContoh: ρ=1000kg/m³, g=10, h=2m → P=20000Pa',
        'Tekanan Hidrostatis': 'Ph = ρ × g × h\nContoh: ρ=1000, g=9.8, h=5 → Ph=49000Pa'
      },
      '5. Gelombang': {
        'Cepat Rambat Gelombang': 'v = λ × f\nContoh: λ=2m, f=5Hz → v=10m/s',
        'Frekuensi': 'f = n / t\nContoh: n=100 getaran, t=20s → f=5Hz'
      }
    };

    const generateMenu = () => {
      let menu = '📚 *MENU UTAMA RUMUS IPA*\n\n';
      Object.keys(semuaRumus).forEach(kategori => {
        menu += `*${kategori}*\n`;
        Object.keys(semuaRumus[kategori]).forEach(rumus => {
          menu += `- ${rumus}\n`;
        });
        menu += '\n';
      });
      menu += `\nContoh penggunaan:\n*${prefix}rumus 1* → lihat rumus dalam kategori\n*${prefix}rumus 1.1* → lihat detail rumus`;
      return menu;
    };

    const sendPreview = async (text) => {
      const thumb = await (await fetch(thumbnailUrl)).buffer();
      return conn.sendMessage(m.chat, {
        text,
        contextInfo: {
          externalAdReply: {
            title: "📘 Rumus IPA Lengkap",
            body: "Kumpulan rumus Fisika dan Sains untuk pelajar",
            thumbnail: thumb,
            mediaType: 1,
            mediaUrl: "https://google.com",
            sourceUrl: "https://google.com"
          }
        }
      });
    };

    if (!text) {
      return sendPreview(generateMenu());
    }

    const [bagian, subBagian] = text.split('.');
    const kategoriIndex = parseInt(bagian) - 1;
    const kategoriKeys = Object.keys(semuaRumus);

    if (isNaN(kategoriIndex) || kategoriIndex < 0 || kategoriIndex >= kategoriKeys.length) {
      return sendPreview(`❌ Kategori tidak ditemukan.\n\nKetik *${prefix}rumus* untuk melihat menu.`);
    }

    const kategori = kategoriKeys[kategoriIndex];
    const rumusKeys = Object.keys(semuaRumus[kategori]);

    if (!subBagian) {
      const subMenu = rumusKeys.map((r, i) => `${bagian}.${i + 1} - ${r}`).join('\n');
      return sendPreview(`📂 *${kategori}*\n\n${subMenu}\n\nKetik *${prefix}rumus ${bagian}.1* untuk melihat detail rumus.`);
    }

    const rumusIndex = parseInt(subBagian) - 1;

    if (isNaN(rumusIndex) || rumusIndex < 0 || rumusIndex >= rumusKeys.length) {
      return sendPreview('❌ Nomor rumus tidak valid!');
    }

    const rumus = rumusKeys[rumusIndex];
    const isi = semuaRumus[kategori][rumus];

    return sendPreview(`📝 *${rumus}*\n\n${isi}`);
  },
  limit: false,
  api: {
    path: '/api/rumus',
    method: 'get',
    handler: async (req, res) => {
      res.json({
        status: 'success',
        message: 'Daftar rumus IPA',
        thumbnail: 'https://i.ibb.co/3kV0dNV/ipa-logo.jpg',
        data: {
          Mekanika: {
            'Gaya (F=ma)': 'F = m × a',
            'Energi Kinetik': 'Ek = ½ × m × v²'
          },
          Listrik: {
            'Hukum Ohm': 'V = I × R',
            'Daya Listrik': 'P = V × I'
          },
          Termodinamika: {
            'Gas Ideal': 'PV = nRT',
            'Kalor': 'Q = m × c × ΔT'
          },
          Tekanan: {
            'Tekanan Zat Cair': 'P = ρ × g × h',
            'Tekanan Hidrostatis': 'Ph = ρ × g × h'
          },
          Gelombang: {
            'Cepat Rambat Gelombang': 'v = λ × f',
            'Frekuensi': 'f = n / t'
          }
        }
      });
    }
  }
};