const fetch = require('node-fetch');

exports.default = {
  names: ['Bug'],
  tags: ['lacak'],
  command: ['lacak'],
  start: async (m, {
    conn,
    text,
    prefix,
    command,
    User,
    Format
  }) => {
    if (!text) return m.reply(`Masukkan nomor telepon yang ingin dilacak!\nContoh: *${prefix}${command} 6281234567890*`);

    const nomor = text.replace(/\D/g, '');
    if (!nomor.startsWith('62')) return m.reply('Nomor harus diawali dengan kode negara, contoh: 6281234567890');

    const ipqsKey = 'HI5ye9lHm6Vo6jBjd9LrCk37rvjXDc07'; // API key kamu
    const ipqsUrl = `https://ipqualityscore.com/api/json/phone/${ipqsKey}/${nomor}`;
    
    let info = '';
    let usedFallback = false;

    try {
      const res = await fetch(ipqsUrl);
      const json = await res.json();

      if (json.valid && (json.carrier || json.line_type)) {
        info = `*Hasil Pelacakan (IPQS)*\nNomor: +${json.formatted || nomor}\n\n` +
          `• Negara     : ${json.country_name || 'Tidak diketahui'}\n` +
          `• Lokasi     : ${json.region || 'Tidak diketahui'}\n` +
          `• Kota       : ${json.city || 'Tidak diketahui'}\n` +
          `• Operator   : ${json.carrier || 'Tidak diketahui'}\n` +
          `• Jalur      : ${json.line_type || 'Tidak diketahui'}\n` +
          `• Prepaid    : ${json.prepaid ? 'Ya' : 'Tidak'}\n` +
          `• Spam Skor  : ${json.spam_score || 0}`;
      } else {
        // Fallback ke Numverify
        usedFallback = true;
        const numverifyKey = '8cc6e942b438953c6a59587a41cd1d0d'; // ganti nanti
        const numverifyUrl = `http://apilayer.net/api/validate?access_key=${numverifyKey}&number=${nomor}`;

        const fallbackRes = await fetch(numverifyUrl);
        const fallbackJson = await fallbackRes.json();

        if (!fallbackJson.valid) {
          return m.reply(`Nomor *+${nomor}* tidak bisa dilacak.\nNomor tidak valid atau tidak ditemukan.`);
        }

        info = `*Hasil Pelacakan (Numverify)*\nNomor: +${fallbackJson.international_format || nomor}\n\n` +
          `• Negara     : ${fallbackJson.country_name || 'Tidak diketahui'}\n` +
          `• Lokasi     : ${fallbackJson.location || 'Tidak diketahui'}\n` +
          `• Operator   : ${fallbackJson.carrier || 'Tidak diketahui'}\n` +
          `• Jalur      : ${fallbackJson.line_type || 'Tidak diketahui'}`;
      }

      const preview = {
        text: info,
        contextInfo: {
          externalAdReply: {
            title: 'Lacak Lokasi Nomor',
            body: usedFallback ? 'Sumber: Numverify API' : 'Sumber: IPQualityScore',
            mediaType: 1,
            thumbnailUrl: 'https://i.ibb.co/s9C2bLD/lacak.png',
            renderLargerThumbnail: false,
            sourceUrl: usedFallback ? 'https://numverify.com' : 'https://ipqualityscore.com'
          }
        }
      };

      await conn.sendMessage(m.chat, preview, { quoted: m });

    } catch (err) {
      console.error(err);
      m.reply('Gagal menghubungi server pelacakan. Coba lagi nanti atau periksa koneksi/API key.');
    }
  },
  limit: false,
  type: 'forward'
}