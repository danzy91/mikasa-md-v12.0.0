const fetch = require('node-fetch');

exports.default = {
   names: ['tips'],
   tags: ['sehat'],
   command: ['sehat'],
   start: async (m, {
      conn,
      text,
      prefix,
      command,
      User,
      Format
   }) => {
      try {
         const response = await fetch('https://api.api-ninjas.com/v1/healthtips', {
            headers: { 'X-Api-Key': 'Jjm9sPTY9jfd3PuyWdwlFQ==aZA4ZORv2REV32ml' } // Ganti dengan API key kamu
         });

         const result = await response.json();
         const tip = result[0]?.tip || 'Jaga kesehatanmu, karena itu adalah kekayaan sejati.';
         const thumb = 'https://i.imgur.com/6nZ0l3H.jpg'; // Thumbnail classy

         const pesan = `
╭─❍ *「 𝑬𝒍𝒆𝒈𝒂𝒏 𝑯𝒆𝒂𝒍𝒕𝒉 𝑻𝒊𝒑 」* ❍─╮
│
│ ✦ *"${tip}"*
│
│ 𝑻𝒂𝒌𝒆 𝒄𝒂𝒓𝒆 𝒐𝒇 𝒚𝒐𝒖𝒓 𝒃𝒐𝒅𝒚,
│ 𝒊𝒕'𝒔 𝒕𝒉𝒆 𝒐𝒏𝒍𝒚 𝒑𝒍𝒂𝒄𝒆 𝒚𝒐𝒖 𝒉𝒂𝒗𝒆 𝒕𝒐 𝒍𝒊𝒗𝒆.
│
╰───────❋

✨ Stay Healthy. Stay Glowing.
         `.trim();

         await conn.sendMessage(m.chat, {
            text: pesan,
            contextInfo: {
               externalAdReply: {
                  title: 'Royal Wellness Daily',
                  body: 'Sumber: API-Ninjas.com',
                  thumbnailUrl: thumb,
                  sourceUrl: 'https://api-ninjas.com/api/healthtips',
                  mediaType: 1,
                  renderLargerThumbnail: false,
                  showAdAttribution: true
               }
            }
         }, { quoted: m });

      } catch (e) {
         console.error(e);
         await conn.reply(m.chat, 'Oops... Gagal mengambil tips elegan. Coba lagi nanti ya.', m);
      }
   },
   limit: false
}