exports.default = {
  names: ['Tools'],
  tags: ['spamtext', 'spam'], // Biasanya tag owner karena berpotensi mengganggu
  command: ['spamtext'],
  owner: true, // Hanya bisa digunakan oleh owner bot
  start: async (m, { conn, text, args }) => {
    if (!text) {
      return m.reply(`Penggunaan: ${m.prefix}${m.command} <@tag> <jumlah> <pesan>\nContoh: ${m.prefix}${m.command} @user 5 Halo!`);
    }

    const [tag, jumlahStr, ...pesanArr] = text.split(' ');
    const jumlah = parseInt(jumlahStr);
    const pesan = pesanArr.join(' ');

    if (!tag || isNaN(jumlah) || jumlah <= 0 || !pesan) {
      return m.reply(`Penggunaan salah. Harap masukkan tag pengguna, jumlah spam, dan pesan yang valid.\nContoh: ${m.prefix}${m.command} @teman 3 Selamat malam!`);
    }

    const targetNumber = tag.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
    if (!targetNumber) {
      return m.reply('Tag pengguna tidak valid.');
    }

    if (jumlah > 1000) { // Batasi jumlah spam agar tidak berlebihan
      return m.reply('Jumlah spam terlalu banyak! Maksimal 10 kali.');
    }

    m.reply(`Memulai spam sebanyak ${jumlah} kali dengan pesan: "${pesan}" ke ${tag}`);

    for (let i = 0; i < jumlah; i++) {
      try {
        await conn.sendMessage(targetNumber, { text: pesan });
        // Anda bisa menambahkan jeda waktu di sini jika perlu, tapi hati-hati bisa menyebabkan masalah
        // await new Promise(resolve => setTimeout(resolve, 500)); // Jeda 500ms (0.5 detik)
      } catch (error) {
        console.error(`Gagal mengirim spam ke ${tag}:`, error);
        m.reply(`Gagal mengirim spam ke ${tag} pada pengulangan ke-${i + 1}.`);
        break; // Hentikan spam jika ada error
      }
    }

    m.reply(`Spam selesai dikirim ke ${tag}!`);
  },
};
