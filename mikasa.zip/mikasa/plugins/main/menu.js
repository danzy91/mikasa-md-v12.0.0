exports.default = {
  names: ['Main Menu'],
  tags: ['menu'],
  command: ['menu', 'help', 'allmenu', 'command', 'm', 'all', 'meni'],
  start: async (m, { conn, text, prefix, command, Format }) => {
    const sosmed = setting.sosmed.toLowerCase().replace('https://', '');
    const garis = '';
    const side = '';
    const top = '';
    const bot = '';
    const { Upload, Download } = await Format.statistic();
    const title = `${setting.botName}\n${setting.footer}`;
    const music = setting.music;
    const lolim = logo_limit || 'Ⓛ';
    const loprem = logo_premium || 'Ⓟ';
    const select = 'SELECT HERE';
    const header_sub = 'LIST MENU';
    const header = '┌────';
    const middle = '│';
    const pointer = '⭓';
    const bottom = '└──────────⭓\n';
    const left = '『';
    const right = '』';
    const bigHeader = false;
    const type = db.settings.menu_type || 3; // default ke 3 kalau belum diset
    const top_1 = { left, right, bigHeader, text, header_sub, select, type, command };
    const audio = () => conn.sendFile(m.chat, setting.music, '', m, { ptt: true });

    let info = `
┏━━【 兵団作戦レポート 】━━┓
┃ BOT NAME : *${setting.botName}*
┃ SCOUT NAME : @${m.sender.split('@')[0]}
┃ MISSION TIME : ${waktu.suasana.toUpperCase()}
┃ TOTAL COMMAND USED : ${db.users[m.sender].hitCmd} TIMES
┃
┃ ┌──【 STATUS 】───┐
┃ │ Owner       : +${setting.contact}
┃ │ SM Division : ${sosmed}
┃ │ Download    : ${Download}
┃ │ Upload      : ${Upload}
┃ └───────────────┘
┃
┃ SYMBOLS:
┃ ${lolim} = Cadet (Limit)
┃ ${loprem} = Elite (Premium)
┃
┃ 「 *Shinzou wo Sasageyo!!!* 」
┗━━━━━━━━━━━━━━━┛
`;

    const opts = [
      { title: 'Owner', id: '.owner' },
      { title: 'Sewa', id: '.sewa' },
      { title: 'Source Code', id: '.sc' }
    ];

    if (type === 1) {
      m.react('1⃣');
      m.react('📔')
      const all_menu = await Format.Menu(header, middle, pointer, bottom, prefix, top_1);
      conn.adReply(m.chat, `${info}\n${all_menu}`, cover, m, { showAds: true });
      audio();
    } else if (type === 2) {
      m.react('2⃣');
      m.react('📋')
      const sub_menu = await Format.Menu(header, middle, pointer, bottom, prefix, top_1);
      conn.adReply(m.chat, `${info}\n${sub_menu}`, cover, m, { showAds: true });
      audio();
    } else if (type === 3) {
      m.react('3⃣');
      m.react('📓')
      const { menu, message } = await Format.Menu(header, middle, pointer, bottom, prefix, top_1, opts);

      if (!text) {
        conn.sendList(m.chat, info, message, m, {
          isMedia: true,
          media: {
            image: {
              url: cover
            }
          }
        });
        audio();
      } else if (text || text.toLowerCase() === 'all') {
        conn.sendList(m.chat, `${info}\n${menu}`, message, m, {
          isMedia: true,
          media: {
            image: {
              url: cover
            }
          }
        });
        audio();
      }
    }
  }
};