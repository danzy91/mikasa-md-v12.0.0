const fs = require('fs');
const reminderFile = './reminders.json';

// Baca file atau buat baru kalau belum ada
let reminders = {};
if (fs.existsSync(reminderFile)) {
   reminders = JSON.parse(fs.readFileSync(reminderFile));
} else {
   fs.writeFileSync(reminderFile, JSON.stringify(reminders, null, 2));
}
exports.default = {
   names: ['Pengingat'],
   tags: ['life', 'reminder'],
   command: ['ingatkan', 'lihatpengingat', 'hapuspengingat'],
   start: async (m, {
      conn,
      text,
      prefix,
      command
   }) => {
      const fs = require('fs');
      const reminderFile = './reminders.json';

      let reminders = {};
      if (fs.existsSync(reminderFile)) {
         reminders = JSON.parse(fs.readFileSync(reminderFile));
      }

      const userId = m.sender;
      reminders[userId] = reminders[userId] || [];

      if (command === 'ingatkan') {
         const match = text.match(/^(\d{1,2}:\d{2})\s+(.+)$/);
         if (!match) return m.reply(`Format salah!\nContoh: ${prefix}${command} 07:00 Bangun tidur`);

         const waktu = match[1];
         const kegiatan = match[2];

         reminders[userId].push({ waktu, kegiatan, triggered: false });
         fs.writeFileSync(reminderFile, JSON.stringify(reminders, null, 2));

         return m.reply(`Pengingat ditambahkan:\nJam: ${waktu}\nKegiatan: ${kegiatan}`);
      }

      if (command === 'lihatpengingat') {
         if (reminders[userId].length === 0) return m.reply('Kamu belum punya pengingat.');

         const list = reminders[userId].map((r, i) => `${i + 1}. ${r.waktu} - ${r.kegiatan}`).join('\n');
         return m.reply(`Daftar pengingatmu:\n\n${list}`);
      }

      if (command === 'hapuspengingat') {
         const index = parseInt(text) - 1;
         if (isNaN(index) || index < 0 || index >= reminders[userId].length)
            return m.reply(`Nomor tidak ditemukan!`);

         const removed = reminders[userId].splice(index, 1)[0];
         fs.writeFileSync(reminderFile, JSON.stringify(reminders, null, 2));

         return m.reply(`Pengingat "${removed.kegiatan}" jam ${removed.waktu} berhasil dihapus.`);
      }
   },
   limit: false
}