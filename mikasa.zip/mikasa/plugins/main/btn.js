exports.default = {
   names: ['Main Menu'],
   tags: ['random image'],
   command: ['random image','ri'],
   start: async (m, {
      conn,
      text,
      prefix,
      command,
      Format
   }) => {
      text = text || 'contoh'
      m.reply('fitur ini dalah tahap pengembangan jadi mohon maaf jika image yang adnda inginkan tidak sesuai⚠️')
      let caption = `Hay Ka @${m.sender.split('@')[0]}` // Pesan nya atau caption
      let media = cover //media photo or video 
      //button disini hanya contoh saja dan bisa kalian buat sesuai keinginan dan terapkan ke plugins lain dan juga total buttonya
      let button = [
         ['ukhti', '.gimage ukhti'], //text atau command dari kita, tanda koma perhatikan biar ga eror
         ['toblut', '.gimage tobrut'],  //text dari user    
         ['pict mobil', '.gimage mobil balap'],
         ['random', '.gimage gambar meme'],
         ['random 2', '.gimage gambar apa saja yang menatik'],
         ['buton 2', '.gimage toblut']
      ] 
      conn.sendButton(m.chat, caption, media, m, button)
   }
}
