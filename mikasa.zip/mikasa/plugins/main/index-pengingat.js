const fs = require('fs');
const reminderFile = './reminders.json';

setInterval(async () => {
   try {
      if (!fs.existsSync(reminderFile)) return;
      const reminders = JSON.parse(fs.readFileSync(reminderFile));
      const now = new Date();
      const jamSekarang = now.toTimeString().slice(0, 5); // format: HH:MM

      let updated = false;

      for (const jid in reminders) {
         const userReminders = reminders[jid];
         const newReminders = [];

         for (const r of userReminders) {
            if (r.waktu === jamSekarang) {
               await conn.sendMessage(jid, {
                  text: `⏰ Pengingat:\n${r.kegiatan}\n(Waktu: ${r.waktu})`
               });
               updated = true;
            } else {
               newReminders.push(r); // simpan yang belum waktunya
            }
         }

         // update data user
         reminders[jid] = newReminders;
      }

      if (updated) {
         fs.writeFileSync(reminderFile, JSON.stringify(reminders, null, 2));
         console.log(`[PENGINGAT] Sudah dikirim dan dibersihkan - ${jamSekarang}`);
      }
   } catch (err) {
      console.error('[PENGINGAT ERROR]', err);
   }
}, 60 * 1000); // cek setiap menit