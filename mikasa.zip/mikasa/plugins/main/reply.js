exports.default = {
 //  names: ['Main Menu'],
   //tags: ['apa yang harus di ketik'],
   command: ['dan', 'wildan'],
   start: async (m, {
      conn,
      Format
   }) => {
      /**
       * example simple send message
       */
      //example reply message without advertisement
      conn.adReply(m.chat, 'maaf kak 🙏, nomor ini adalah nomor bot sekarang jadi Silahkan Ketik .menu untuk menampilkan list pertintah yang harus anda berikan ke saya😃 \n\nＴＥＲＩＭＡＫＡＳＩＨ🙏', cover, m, {
         showAds: false,  // or true with advertisement
         manyForward: false //true with forwarded manytimes ads must be false
      })                
   }
};