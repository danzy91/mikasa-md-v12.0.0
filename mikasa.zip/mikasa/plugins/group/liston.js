exports.default = {
   names: ['ListOnline', 'ListOn'],
   tags: ['group'],
   command: ['listonline', 'liston'],
   start: async (m, {
      conn,
      text,
      prefix,
      command,
      User,
      Format,
      args,
      store,
      botNumber,
      mess
   }) => {
      if (!m.isGroup) return m.reply(mess.group)
      
      let id = args && /\d+\-\d+@g.us/.test(args[0]) ? args[0] : m.chat
      if (!store.presences || !store.presences[id]) return m.reply('Sedang Tidak ada yang online!')

      let online = [...Object.keys(store.presences[id]), botNumber]

      try {
         await m.reply('List Online:\n\n' + online.map(v => '• @' + v.replace(/@.+/, '')).join`\n`, {
            mentions: online
         })
      } catch (e) {
         m.reply('Sedang Tidak Ada Yang Online..')
      }
   },
   limit: false
}