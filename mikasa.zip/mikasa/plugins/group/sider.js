exports.default = {
   names: ['Group Menu'],
   tags: ['sider'],
   command: ['sider'],
   admin: true,
   group: true,
   start: async (m, { conn, participants, groupMetadata, command }) => {
      const days = 3;
      const inactiveTime = days * 24 * 60 * 60 * 1000; // 3 hari dalam milisekon
      const now = Date.now();
      const taggedUsers = [];
      const groupAdmins = (participants.filter(p => p.admin !== null) || []).map(p => p.id);

      if (!groupMetadata) {
         return m.reply('Metadata grup tidak ditemukan.');
      }

      const info = `👥 *MENANDAI PENGGUNA TIDAK AKTIF (${days} HARI TERAKHIR})*\n\n`;
      let teks = info;
      let count = 0;

      for (const participant of participants) {
         const lastSeen = await conn.fetchStatus(participant.id).catch(() => {});
         if (lastSeen && lastSeen.lastSeen) {
            const timeDiff = now - new Date(lastSeen.lastSeen).getTime();
            if (timeDiff > inactiveTime && !groupAdmins.includes(participant.id) && !areJidsSameUser(participant.id, conn.user.id)) {
               taggedUsers.push(participant.id);
               teks += `(${++count}) @${participant.id.split('@')[0]}\n`;
            }
         } else if (!groupAdmins.includes(participant.id) && !areJidsSameUser(participant.id, conn.user.id)) {
            // Jika lastSeen tidak tersedia, anggap tidak aktif (opsional, bisa diubah)
            taggedUsers.push(participant.id);
            teks += `(${++count}) @${participant.id.split('@')[0]} (Status tidak diketahui)\n`;
         }
      }

      if (taggedUsers.length === 0) {
         return m.reply('Tidak ada pengguna yang tidak aktif selama 3 hari terakhir di grup ini.');
      }

      teks += `\nJumlah pengguna tidak aktif: ${taggedUsers.length}`;

      conn.sendMessage(m.chat, {
         text: teks,
         mentions: taggedUsers
      }, { quoted: m });
   }
};
