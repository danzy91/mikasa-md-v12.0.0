let globalConn // simpan koneksi secara global

exports.default = {
  names: ['AntiKesurupan'],
  tags: ['proteksi', 'anti'],
  command: ['ruqyah'],
  start: async (m, {
    conn,
    text,
    prefix,
    command
  }) => {
    globalConn = conn // simpan conn agar bisa dipakai di luar
    if (!text) {
      return m.reply(`Contoh:\n${prefix + command} aktif\n${prefix + command} nonaktif`);
    }

    if (text.toLowerCase() === 'aktif') {
      global.antiKesurupan = true;
      return m.reply('Fitur anti kesurupan berhasil *diaktifkan*.');
    } else if (text.toLowerCase() === 'nonaktif') {
      global.antiKesurupan = false;
      return m.reply('Fitur anti kesurupan *dinonaktifkan*.');
    } else {
      return m.reply('Gunakan "aktif" atau "nonaktif".');
    }
  },
  limit: true
}

global.antiKesurupan = false

// Deteksi otomatis pesan kesurupan
setInterval(() => {
  if (!globalConn || !global.antiKesurupan) return;

  globalConn.ev.on('messages.upsert', async chatUpdate => {
    const m = chatUpdate.messages[0];
    if (!m || !m.message || m.key.fromMe || m.isBaileys) return;

    const teks = m.message?.conversation || m.message?.extendedTextMessage?.text || '';
    const kataKesurupan = ['hantu', 'setan', 'kerasukan', 'kesurupan', 'ngamuk', 'jerit', 'teriak'];

    if (kataKesurupan.some(k => teks.toLowerCase().includes(k))) {
      try {
        const pesan = "Tenang... Bot sedang menenangkan suasana dengan ruqyah.";

        await globalConn.sendMessage(m.key.remoteJid, {
          text: `*Anti Kesurupan Aktif*\n\n${pesan}`,
          contextInfo: {
            externalAdReply: {
              title: "Ruqyah Digital",
              body: "Menetralkan energi negatif...",
              thumbnailUrl: "https://i.imgur.com/WyXHcjg.jpg",
              sourceUrl: "https://archive.org/details/Ar-ruqyahAs-shariahRecitationBySheikhAhmadAlAjmi",
              mediaType: 1,
              renderLargerThumbnail: false,
              showAdAttribution: true
            }
          }
        }, { quoted: m });

        await globalConn.sendMessage(m.key.remoteJid, {
          audio: {
            url: "https://ia802601.us.archive.org/27/items/Ar-ruqyahAs-shariahRecitationBySheikhAhmadAlAjmi/Ruqyah%20By%20Sheikh%20Ahmad%20Al%20Ajmi.mp3"
          },
          mimetype: 'audio/mp3',
          ptt: true
        }, { quoted: m });

      } catch (e) {
        console.error("Error ruqyah:", e);
      }
    }
  });
}, 3000); // Cek tiap 3 detik