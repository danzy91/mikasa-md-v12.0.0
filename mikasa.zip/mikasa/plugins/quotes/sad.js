exports.default = {
   names: ['quotes'],
   tags: ['sad'],
   command: ['sad'],
   start: async (m, {
      conn,
      text,
      prefix,
      command,
      User,
      Format
   }) => {
      // Array berisi lebih banyak kata-kata sedih
      const kataSedih = [
         "Setiap malam, bintang-bintang seolah menertawakan kesepianku.",
         "Rindu ini seperti penyakit kronis, datang tanpa permisi dan menetap tanpa ampun.",
         "Aku berjalan di tengah keramaian, namun tetap merasa seperti orang asing.",
         "Senyum yang kupamerkan adalah topeng untuk menyembunyikan hati yang retak.",
         "Waktu menyembuhkan luka, katanya. Tapi mengapa bekasnya terasa begitu nyata?",
         "Mungkin aku ditakdirkan untuk mencintai dari kejauhan.",
         "Air mata adalah kata-kata yang tak bisa diucapkan oleh bibir.",
         "Kenangan indah bersamamu kini terasa seperti mimpi buruk yang berulang.",
         "Aku berharap bisa menghapusmu dari ingatanku, seperti menghapus pesan yang tak sengaja terkirim.",
         "Hati ini seperti kaca yang pecah, setiap kepingnya adalah serpihan kenangan tentangmu.",
         "Berjuang untuk melupakanmu sama sulitnya dengan mengingat siapa diriku sebelum bertemu denganmu.",
         "Kesendirian ini adalah teman setia yang selalu hadir tanpa diundang.",
         "Aku mencari kebahagiaan di tempat yang salah, dan kini aku tersesat dalam kesedihan.",
         "Dulu, bahumu adalah tempat berlindung. Sekarang, aku tak tahu ke mana harus pergi.",
         "Setiap lagu cinta yang kudengar, selalu mengingatkanku pada kisah kita yang kandas.",
         "Aku merindukan percakapan larut malam dan tawa renyah yang dulu kita bagi.",
         "Mungkin kita bertemu hanya untuk saling menyakiti dan belajar bagaimana cara melepaskan.",
         "Ada bagian dari diriku yang ikut pergi bersamamu.",
         "Aku mencoba membangun kembali diriku, tapi setiap batu bata terasa rapuh tanpa kehadiranmu.",
         "Bukan perpisahan yang menyakitkan, tapi kenyataan bahwa aku harus melanjutkannya tanpamu.",
         "Aku bertanya pada waktu, kapan luka ini akan benar-benar mengering.",
         "Melihatmu bahagia dengan orang lain adalah pil pahit yang harus kutelan setiap hari.",
         "Aku belajar bahwa beberapa orang hanya singgah dalam hidup kita, bukan untuk menetap.",
         "Malam ini terasa lebih dingin tanpa kehangatan pelukmu.",
         "Aku terus mencari jejakmu di setiap sudut kota, berharap ada keajaiban.",
         "Mungkin mencintai seseorang berarti harus siap untuk kehilangan.",
         "Hatiku masih menyimpan namamu di tempat yang paling dalam.",
         "Aku iri pada mereka yang bisa melupakan dengan mudah.",
         "Setiap kali aku memejamkan mata, wajahmu selalu hadir dalam mimpiku.",
         "Aku lelah berpura-pura kuat."
      ];

      // Menghasilkan indeks acak dari array kataSedih
      const randomIndex = Math.floor(Math.random() * kataSedih.length);

      // Mendapatkan kata sedih acak berdasarkan indeks
      const randomSedih = kataSedih[randomIndex];

      // Mengirimkan kata sedih acak kepada pengguna
      m.reply(randomSedih);

      // Kode kamu atau kode Anda selanjutnya bisa diletakkan di sini
   }
}
