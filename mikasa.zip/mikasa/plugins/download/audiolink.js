exports.default = {
   names: ['Downloader'],
   tags: ['link to sound','lts'],
   command: ['link to sound', 'lts'],
   start: async (m, {
      conn,
      text,
      prefix,
      command,
      User,
      Format
   }) => {
      if (!text) {
         return m.reply(`Penggunaan: ${prefix}${command} <URL_AUDIO>\nContoh: ${prefix}${command} https://example.com/audio.mp3`);
      }

      try {
         await conn.sendMessage(m.chat, {
            audio: {
               url: text
            },
            mimetype: 'audio/mpeg' // Ubah mimetype jika format audio berbeda
         }, {
            quoted: m
         });
      } catch (error) {
         console.error("Gagal mengirim audio:", error);
         m.reply(`Maaf, gagal mengirim audio dari URL tersebut. Pastikan URL valid dan dapat diakses.`);
      }
   }
};
