exports.default = {
   //names: ['Downloader'],
 //  tags: ['sound'],
  command: ['x1','x2','x3'], // Daftar command yang akan mengirimkan link
   start: async (m, {
      conn,
      text,
      prefix,
      command,
      User,
      Format
   }) => {
      let linkToSend = '';

      switch (command) {
         case 'x1':
            linkToSend = 'https://link-anda.com/punya-kamu'; // Ganti dengan link pribadi Anda
            break;
         case 'x2':
            linkToSend = 'https://website-contoh.com'; // Ganti dengan link website yang ingin Anda kirim
            break;
         case 'x3':
            linkToSend = 'https://instagram.com/akun_sosmed_anda'; // Ganti dengan link media sosial Anda
            break;
         default:
            return m.reply(`silahkan pilih sound yang ingin ada simpan atau di dengar.\nGunakan: \n${prefix}kane\n${prefix}brutal \n${prefix}slow`);
      }

      if (linkToSend) {
         m.reply(`Silakan kunjungi link berikut: ${linkToSend}`);
      }
   }
};
