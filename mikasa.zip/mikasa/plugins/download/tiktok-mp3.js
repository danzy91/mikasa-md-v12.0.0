const { ttdl } = require('ruhend-scraper');
exports.default = {
   //names: ['Downloader'],
   //tags: ['ttmp3'],
   command: ['t3'],
   start: async (m, {
      conn,
      text,
      prefix,
      command
   }) => {
      if (!text) return m.reply(`Masukan link tiktok nya! \nContoh: ${prefix + command} https://vt.tiktok.com/ZSNYfYdLj`);
      //conn.adReply(m.chat, loading, cover, m);
    m.react('⏱️')
      let { music } = await ttdl(text);
     m.react('✅')
      conn.sendFile(m.chat, music, {
         mimetype: 'audio/mp3',
         ptt: true,
         quoted: m
      });
   },
   limit: false
};
