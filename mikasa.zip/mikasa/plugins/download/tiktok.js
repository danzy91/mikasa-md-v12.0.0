const { ttdl } = require('ruhend-scraper');

exports.default = {
   command: ['t'],
   start: async (m, {
      conn,
      text,
      prefix,
      command
   }) => {
      if (!text) return m.reply(`Masukan Tiktok contoh\n${prefix+command} https://vt.tiktok.com/ZSYfBvx5d/`)
      if (text.includes('Postingan ini dibagikan via TikTok Lite.')) return m.reply('Salin Link Nya Ajh Belegug');
      
      let loading = true;

      // Mulai reaksi loading berulang
      const reactLoop = async () => {
         while (loading) {
            try {
               await conn.sendMessage(m.chat, {
                  react: {
                     text: '⏱',
                     key: m.key
                  }
               });
               await new Promise(resolve => setTimeout(resolve, 1500));
            } catch (e) {
               console.error('Gagal kirim reaksi loading:', e.message);
               break;
            }
         }
      };

      reactLoop();

      try {
         const { title, author, username, published, like, comment, share, views, bookmark, video, cover: picture, music, profilePicture } = await ttdl(text);

         let caption = `${head("𝐓𝐈𝐊𝐓𝐎𝐊")} \n`
         caption += `⭔ *Author:* ${author}\n`
         caption += `⭔ *Username:* ${username}\n`
         caption += `⭔ *Description:* ${title}\n`
         caption += `⭔ *Published:* ${published}\n`
         caption += `⭔ *Like:* ${like}\n`
         caption += `⭔ *Comment:* ${comment}\n`
         caption += `⭔ *Views:* ${views}\n`
         caption += `⭔ *Bookmark:* ${bookmark}\n`
         caption += `${zw} ${namebot}\n ${wm}`

         await conn.adReply(m.chat, author, picture, m)
         await conn.sendFile(m.chat, video, {
            caption: caption,
            quoted: m
         })

         loading = false; // stop loop
         await conn.sendMessage(m.chat, {
            react: {
               text: '✅',
               key: m.key
            }
         });
      } catch (err) {
         console.error("ada kesalahan saat mendownload", err)
         loading = false;
         await conn.sendMessage(m.chat, {
            react: {
               text: '❌',
               key: m.key
            }
         });
         return m.reply('Gagal mendownload video TikTok.');
      }
   },
   limit: false
}