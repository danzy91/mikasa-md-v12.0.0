exports.default = {
   names: ['Downloader'],
   tags: ['sound'],
   command: ['sound'],
   start: async (m, {
      conn,
      text,
      prefix,
      command,
      Format
   }) => {
      text = text || 'contoh'
      m.reply('silahkan pilih sesuai yang anda butuhkan⚠️')
      let caption = `Hay Ka @${m.sender.split('@')[0]}` 
      let media = cover 
      let button = [
         ['kane', '.x1'],
         ['slowed + kane', '.x2'],  
         ['brutal', '.x3']
      ] 
      conn.sendButton(m.chat, caption, media, m, button)
   }
}
