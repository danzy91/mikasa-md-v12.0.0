const { default: makeWASocket, useMultiFileAuthState } = require('@adiwajshing/baileys');
const path = require('path');
const qrcode = require('qrcode');

exports.default = {
   names: ['User Menu'],
   tags: ['jadibot'],
   command: ['jadibot'],
   start: async (m, {
      conn,
      text,
      prefix
   }) => {
      const sessionId = 'subbot-' + Date.now();
      const sessionFolder = path.join(__dirname, '../../subbot-sessions', sessionId);
      const { state, saveCreds } = await useMultiFileAuthState(sessionFolder);

      const sock = makeWASocket({
         auth: state,
         printQRInTerminal: false,
         browser: ['SubBot', 'Chrome', '1.0.0'],
         logger: conn.logger
      });

      sock.ev.on('creds.update', saveCreds);

      sock.ev.on('connection.update', async (update) => {
         const { qr, connection, lastDisconnect } = update;

         if (qr) {
            try {
               const qrImage = await qrcode.toBuffer(qr, { scale: 10 });
               await conn.sendMessage(m.sender, {
                  image: qrImage,
                  caption: 'Scan QR ini dengan WhatsApp kamu untuk menjadi sub-bot.'
               }, { quoted: m });
            } catch (err) {
               console.error('Gagal buat QR:', err);
               await m.reply('Gagal membuat QR code.');
            }
         }

         if (connection === 'open') {
            await m.reply('Berhasil terkoneksi! Nomor kamu sekarang menjadi sub-bot.');
         }

         if (connection === 'close') {
            const reason = lastDisconnect?.error?.output?.statusCode;
            if (reason !== 401) {
               await m.reply('Koneksi sub-bot terputus.');
            }
         }
      });

      sock.ev.on('messages.upsert', async ({ messages }) => {
         const msg = messages[0];
         if (!msg.message || msg.key.fromMe) return;

         const teks = msg.message.conversation || msg.message.extendedTextMessage?.text || '';
         if (teks.toLowerCase() === 'ping') {
            await sock.sendMessage(msg.key.remoteJid, { text: 'Pong dari Sub-Bot!' }, { quoted: msg });
         }

         // Tambahkan perintah lainnya di sini
      });
   },
   limit: false
}