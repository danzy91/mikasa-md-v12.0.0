const fs = require('fs');

exports.default = {
   names: ['User Menu'],
   tags: ['daftar'],
   command: ['daftar', 'verify', 'v', 'register', 'reg'],
   start: async (m, {
      conn,
      text,
      prefix,
      command,
      Format
   }) => {
      let sender = m.sender;
      if (db.users[sender]?.registered) return m.reply(`❗Kamu sudah terdaftar.`);

      let nama = text.split(".")[0];
      let umur = text.split(".")[1];
      if (!nama || !umur) return m.reply(`Masukkan nama dan umur dengan benar.\nContoh: ${prefix + command} danzz.20`);

      let sn = Format.makeid(10);
      let date = `${waktu.tanggal} ${waktu.time} ${waktu.suasana}`;

      db.users[sender] = {
         registered: true,
         registeredTime: date,
         name: nama,
         umur: umur,
         seri: sn,
         limit: 15,
         hitCmd: 0,
         premium: false
      };

      // Simpan ke file database (jika pakai fs)
      fs.writeFileSync('./database.json', JSON.stringify(db, null, 2));

      let verified = `✅ Berhasil Daftar!\n\n`;
      verified += `Nama: ${nama}\n`;
      verified += `Umur: ${umur}\n`;
      verified += `Serial Number: ${sn}\n`;
      verified += `Bonus: 15 Limit\n\n`;
      verified += `Ketik *.meni* untuk membuka menu.`;

      conn.adReply(m.chat, verified, cover, m);
   }
};