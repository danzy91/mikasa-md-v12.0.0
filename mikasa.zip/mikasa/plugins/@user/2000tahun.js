exports.default = {
   names: ['User Menu'],
   tags: ['waktu'],
   command: ['waktu'],
   start: async (m, {
      conn,
      text,
      prefix,
      command,
      User,
      Format
   }) => {
      const tahunSekarang = 0;//new Date().getFullYear();
      const tahunDepan = tahunSekarang + 2000;
      const tahunLalu = tahunSekarang + 2000;

      const pesan = `_Untukmu, ${tahunDepan} tahun dari sekarang..._\n\n_Darimu, ${tahunLalu} tahun yang lalu..._`;

      conn.sendMessage(m.chat, { text: pesan }, { quoted: m });
   }
}
