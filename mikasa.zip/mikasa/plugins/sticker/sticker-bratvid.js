exports.default = {
  // names: ['Maker'],
   //tags: ['bratvid'],
   command: ['bv'],
   start: async (m, {
      conn,
      text,
      prefix,
      command
   }) => {
   //m.reply('maaf saat ini system brat video sedang di perbaiki silahkan tunggu beberapa saat⚠️ \n> 𝚃𝙴𝚁𝚂𝙸𝙼𝙰𝙺𝙰𝚂𝙸𝙷🙏')
      if (!text) return m.reply(`Kirim perintah ${prefix+command} text\ncontoh: ${prefix+command} ${setting.botName}`);
      const result = await BUFFER_URL(`https://fastrestapis.fasturl.cloud/maker/brat/animated?text=${text}&mode=animated`);
      //conn.adReply(m.chat, loading, cover, m).then(() => {            
         conn.sendImageAsSticker(m.chat, result, m, {
           packname: setting.botName,
           author: `${setting.footer}\ncreated: \n${waktu.tanggal}\n${waktu.time} ${waktu.suasana}`
         })
      //})
   },
   limit: false
}