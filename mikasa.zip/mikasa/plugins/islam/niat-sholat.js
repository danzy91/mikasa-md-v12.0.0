exports.default = {
    names: ['Islam'],
    tags: ['niatsholat'],
    command: ['niatsholat'], // Tambahkan 'niatshalat' sebagai alias
    start: async (m, { conn, text, prefix, command }) => {
        const niatSholatLengkap = {
            subuh: {
                arab: 'أُصَلِّي فَرْضَ الصُّبْحِ رَكْعَتَيْنِ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلَّهِ تَعَالَى',
                latin: 'Ushalli fardhas subhi rak’ataini mustaqbilal qiblati adaa-an lillaahi ta’aalaa.',
                arti: 'Aku niat sholat fardhu Subuh dua rakaat menghadap kiblat karena Allah ta’ala.',
            },
            dzuhur: {
                arab: 'أُصَلِّي فَرْضَ الظُّهْرِ أَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلَّهِ تَعَالَى',
                latin: 'Ushalli fardhazh zhuhri arba’a raka’aatin mustaqbilal qiblati adaa-an lillaahi ta’aalaa.',
                arti: 'Aku niat sholat fardhu Dzuhur empat rakaat menghadap kiblat karena Allah ta’ala.',
            },
            ashar: {
                arab: 'أُصَلِّي فَرْضَ الْعَصْرِ أَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلَّهِ تَعَالَى',
                latin: 'Ushalli fardhal ‘ashri arba’a raka’aatin mustaqbilal qiblati adaa-an lillaahi ta’aalaa.',
                arti: 'Aku niat sholat fardhu Ashar empat rakaat menghadap kiblat karena Allah ta’ala.',
            },
            maghrib: {
                arab: 'أُصَلِّي فَرْضَ الْمَغْرِبِ ثَلَاثَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلَّهِ تَعَالَى',
                latin: 'Ushalli fardhal maghribi thalaatha raka’aatin mustaqbilal qiblati adaa-an lillaahi ta’aalaa.',
                arti: 'Aku niat sholat fardhu Maghrib tiga rakaat menghadap kiblat karena Allah ta’ala.',
            },
            isya: {
                arab: 'أُصَلِّي فَرْضَ الْعِشَاءِ أَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلَّهِ تَعَالَى',
                latin: 'Ushalli fardhal ‘isyaa-i arba’a raka’aatin mustaqbilal qiblati adaa-an lillaahi ta’aalaa.',
                arti: 'Aku niat sholat fardhu Isya empat rakaat menghadap kiblat karena Allah ta’ala.',
            },
            jumat: {
                arab: 'أُصَلِّي فَرْضَ الْجُمُعَةِ رَكْعَتَيْنِ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً إِمَامًا/مَأْمُوْمًا لِلَّهِ تَعَالَى',
                latin: 'Ushalli fardhal jumu’ati rak’ataini mustaqbilal qiblati adaa-an imaaman/ma’muuman lillaahi ta’aalaa.',
                arti: 'Aku niat sholat fardhu Jumat dua rakaat menghadap kiblat sebagai imam/makmum karena Allah ta’ala.',
            },
            jenazah: {
                arab: 'أُصَلِّي عَلَى هَذَا الْمَيِّتِ/هَذِهِ الْمَيِّتَةِ أَرْبَعَ تَكْبِيْرَاتٍ فَرْضَ الْكِفَايَةِ إِمَامًا/مَأْمُوْمًا لِلَّهِ تَعَالَى',
                latin: 'Ushalli ‘alaa haadzal mayyiti/haadzihil mayyitati arba’a takbiiraatin fardhal kifaayati imaaman/ma’muuman lillaahi ta’aalaa.',
                arti: 'Aku niat sholat atas jenazah laki-laki/perempuan ini empat takbir fardhu kifayah sebagai imam/makmum karena Allah ta’ala.',
            },
            witir: {
                arab: 'أُصَلِّي سُنَّةَ الْوِتْرِ ثَلَاثَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلَّهِ تَعَالَى', // Bisa disesuaikan jumlah rakaat
                latin: 'Ushalli sunnatal witri thalaatha raka’aatin mustaqbilal qiblati adaa-an lillaahi ta’aalaa.', // Sesuaikan jumlah rakaat jika perlu
                arti: 'Aku niat sholat sunnah Witir tiga rakaat menghadap kiblat karena Allah ta’ala.', // Sesuaikan jumlah rakaat jika perlu
            },
            tahajud: {
                arab: 'أُصَلِّي سُنَّةَ التَّهَجُّدِ رَكْعَتَيْنِ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلَّهِ تَعَالَى', // Bisa lebih dari 2 rakaat
                latin: 'Ushalli sunnatat tahajjudi rak’ataini mustaqbilal qiblati adaa-an lillaahi ta’aalaa.', // Sesuaikan jumlah rakaat jika perlu
                arti: 'Aku niat sholat sunnah Tahajud dua rakaat menghadap kiblat karena Allah ta’ala.', // Sesuaikan jumlah rakaat jika perlu
            },
            dhuha: {
                arab: 'أُصَلِّي سُنَّةَ الضُّحَى رَكْعَتَيْنِ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلَّهِ تَعَالَى', // Bisa lebih dari 2 rakaat
                latin: 'Ushalli sunnatadh dhuhaa rak’ataini mustaqbilal qiblati adaa-an lillaahi ta’aalaa.', // Sesuaikan jumlah rakaat jika perlu
                arti: 'Aku niat sholat sunnah Dhuha dua rakaat menghadap kiblat karena Allah ta’ala.', // Sesuaikan jumlah rakaat jika perlu
            },
            rawatib: {
                arab: 'أُصَلِّي سُنَّةَ قَبْلِيَّةِ/بَعْدِيَّةِ [NAMA SHOLAT FARDHU] رَكْعَتَيْنِ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلَّهِ تَعَالَى',
                latin: 'Ushalli sunnata qabliyyatil/ba’diyyati [nama sholat fardhu] rak’ataini mustaqbilal qiblati adaa-an lillaahi ta’aalaa.',
                arti: 'Aku niat sholat sunnah qabliyah/ba’diyah [nama sholat fardhu] dua rakaat menghadap kiblat karena Allah ta’ala.',
            },
        };

        if (command === 'niatsholat' || command === 'niatshalat') {
            if (text) {
                const waktuSholat = text.toLowerCase();
                if (niatSholatLengkap[waktuSholat]) {
                    const niat = niatSholatLengkap[waktuSholat];
                    const message = `*Niat Sholat ${waktuSholat.toUpperCase()}*\n\n` +
                                    `*Arab:* ${niat.arab}\n` +
                                    `*Latin:* ${niat.latin}\n` +
                                    `*Arti:* ${niat.arti}`;
                    m.reply(message);
                } else {
                    let listWaktu = '*Berikut adalah daftar niat sholat yang tersedia:*\n\n';
                    for (const waktu in niatSholatLengkap) {
                        listWaktu += `- ${waktu.toUpperCase()}\n`;
                    }
                    listWaktu += `\n*Cara penggunaan:* ketik *${prefix}${command} [nama_sholat]*. Contoh: *${prefix}${command} subuh* atau *${prefix}${command} jumat*`;
                    m.reply(listWaktu);
                }
            } else {
                let listWaktu = '*Berikut adalah daftar niat sholat yang tersedia:*\n\n';
                for (const waktu in niatSholatLengkap) {
                    listWaktu += `- ${waktu.toUpperCase()}\n`;
                }
                listWaktu += `\n*Cara penggunaan:* ketik *${prefix}${command} [nama_sholat]*. Contoh: *${prefix}${command} subuh* atau *${prefix}${command} jumat*`;
                m.reply(listWaktu);
            }
        }
    },
};
