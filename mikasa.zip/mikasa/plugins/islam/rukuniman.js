exports.default = {
    names: ['Islam'],
    tags: ['rukuniman'],
    command: ['rukuniman'],
    start: async (m, { conn, text, prefix, command }) => {
        const pesan = `*RUKUN IMAN DALAM ISLAM*\n\n` +
                      `Rukun Iman adalah pilar-pilar kepercayaan dasar dalam agama Islam yang wajib diyakini oleh setiap Muslim. Rukun Iman ada enam, yaitu:\n\n` +
                      `*1. Iman kepada Allah SWT:*\n` +
                      `   - Meyakini bahwa Allah adalah satu-satunya Tuhan yang berhak disembah, tidak ada sekutu bagi-Nya.\n` +
                      `   - Mengimani nama-nama dan sifat-sifat Allah yang Maha Sempurna.\n\n` +
                      `*2. Iman kepada Malaikat-malaikat Allah:*\n` +
                      `   - Meyakini keberadaan malaikat sebagai makhluk ciptaan Allah yang taat dan melaksanakan perintah-Nya.\n` +
                      `   - Mengimani nama-nama malaikat yang kita ketahui (seperti Jibril, Mikail, Israfil, Izrail, dll.) beserta tugas-tugas mereka.\n\n` +
                      `*3. Iman kepada Kitab-kitab Allah:*\n` +
                      `   - Meyakini bahwa Allah telah menurunkan kitab-kitab suci kepada para nabi dan rasul-Nya.\n` +
                      `   - Mengimani kitab-kitab yang kita ketahui (seperti Taurat, Zabur, Injil, dan Al-Qur'an), dan Al-Qur'an adalah kitab suci terakhir dan penyempurna kitab-kitab sebelumnya.\n\n` +
                      `*4. Iman kepada Rasul-rasul Allah:*\n` +
                      `   - Meyakini keberadaan para nabi dan rasul sebagai utusan Allah yang menyampaikan wahyu kepada umat manusia.\n` +
                      `   - Mengimani nama-nama rasul yang kita ketahui (seperti Adam, Nuh, Ibrahim, Musa, Isa, dan Muhammad ﷺ adalah nabi dan rasul terakhir).\n\n` +
                      `*5. Iman kepada Hari Akhir (Kiamat):*\n` +
                      `   - Meyakini adanya kehidupan setelah kematian, yaitu Hari Kebangkitan, Hari Perhitungan Amal, Surga sebagai balasan bagi orang yang beriman dan beramal saleh, serta Neraka sebagai hukuman bagi orang yang kafir dan berbuat dosa.\n\n` +
                      `*6. Iman kepada Qada dan Qadar (Ketentuan dan Takdir Allah):*\n` +
                      `   - Meyakini bahwa segala sesuatu yang terjadi di alam semesta ini, baik maupun buruk, telah ditentukan oleh Allah SWT.\n` +
                      `   - Meskipun demikian, manusia tetap memiliki kebebasan untuk berusaha dan bertanggung jawab atas perbuatannya.\n\n` +
                      `Mengimani keenam rukun iman ini adalah kewajiban bagi setiap Muslim dan merupakan landasan utama dalam beragama Islam.`;

        m.reply(pesan);
    },
};
