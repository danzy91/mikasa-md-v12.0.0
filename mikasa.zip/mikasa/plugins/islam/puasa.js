exports.default = {
    names: ['Islam'],
    tags: ['niat'],
    command: ['niatpuasa'],
    start: async (m, { conn, text, prefix, command }) => {
        const niatPuasa = {
            ramadhan: {
                arab: 'نَوَيْتُ صَوْمَ غَدٍ عَنْ أَدَاءِ فَرْضِ شَهْرِ رَمَضَانَ هَذِهِ السَّنَةِ لِلَّهِ تَعَالَى',
                latin: 'Nawaitu shauma ghodin an adaa-i fardhi syahri Ramadhaana haadzihis sanati lillaahi ta’aalaa.',
                arti: 'Aku niat berpuasa esok hari untuk menunaikan kewajiban di bulan Ramadhan tahun ini karena Allah ta’ala.',
            },
            qadha: {
                arab: 'نَوَيْتُ صَوْمَ غَدٍ عَنْ قَضَاءِ فَرْضِ شَهْرِ رَمَضَانَ لِلَّهِ تَعَالَى',
                latin: 'Nawaitu shauma ghodin an qadha-i fardhi syahri Ramadhaana lillaahi ta’aalaa.',
                arti: 'Aku niat berpuasa esok hari untuk mengganti kewajiban puasa di bulan Ramadhan karena Allah ta’ala.',
            },
            sunnah: {
                arab: 'نَوَيْتُ صَوْمَ هَذَا الْيَوْمِ سُنَّةً لِلَّهِ تَعَالَى',
                latin: 'Nawaitu shauma haadzal yaumi sunnatal lillaahi ta’aalaa.',
                arti: 'Aku niat berpuasa hari ini sunnah karena Allah ta’ala.',
            },
            seninkamis: {
                arab: 'نَوَيْتُ صَوْمَ يَوْمِ الِاثْنَيْنِ وَيَوْمِ الْخَمِيسِ سُنَّةً لِلَّهِ تَعَالَى',
                latin: 'Nawaitu shauma yaumil itsnaini wa yaumil khamiisi sunnatal lillaahi ta’aalaa.',
                arti: 'Aku niat berpuasa hari Senin dan hari Kamis sunnah karena Allah ta’ala.',
            },
            arafah: {
                arab: 'نَوَيْتُ صَوْمَ غَدٍ عَنْ صَوْمِ عَرَفَةَ سُنَّةً لِلَّهِ تَعَالَى',
                latin: 'Nawaitu shauma ghodin an shaumi ‘Arafata sunnatal lillaahi ta’aalaa.',
                arti: 'Aku niat berpuasa esok hari, puasa Arafah sunnah karena Allah ta’ala.',
            },
            tarwiyah: {
                arab: 'نَوَيْتُ صَوْمَ غَدٍ عَنْ صَوْمِ تَرْوِيَةَ سُنَّةً لِلَّهِ تَعَالَى',
                latin: 'Nawaitu shauma ghodin an shaumi Tarwiyata sunnatal lillaahi ta’aalaa.',
                arti: 'Aku niat berpuasa esok hari, puasa Tarwiyah sunnah karena Allah ta’ala.',
            },
        };

        if (command === 'niatpuasa') {
            if (text) {
                const jenisPuasa = text.toLowerCase();
                if (niatPuasa[jenisPuasa]) {
                    const niat = niatPuasa[jenisPuasa];
                    const message = `*Niat Puasa ${jenisPuasa.toUpperCase()}*\n\n` +
                                    `*Arab:* ${niat.arab}\n` +
                                    `*Latin:* ${niat.latin}\n` +
                                    `*Arti:* ${niat.arti}`;
                    m.reply(message);
                } else {
                    let listPuasa = '*Berikut adalah daftar jenis puasa yang tersedia:*\n\n';
                    for (const jenis in niatPuasa) {
                        listPuasa += `- ${jenis.toUpperCase()}\n`;
                    }
                    listPuasa += `\n*Cara penggunaan:* ketik *${prefix}niatpuasa [jenis_puasa]*. Contoh: *${prefix}niatpuasa seninkamis*`;
                    m.reply(listPuasa);
                }
            } else {
                let listPuasa = '*Berikut adalah daftar jenis puasa yang tersedia:*\n\n';
                for (const jenis in niatPuasa) {
                    listPuasa += `- ${jenis.toUpperCase()}\n`;
                }
                listPuasa += `\n*Cara penggunaan:* ketik *${prefix}niatpuasa [jenis_puasa]*. Contoh: *${prefix}niatpuasa seninkamis*`;
                m.reply(listPuasa);
            }
        }
    },
};
