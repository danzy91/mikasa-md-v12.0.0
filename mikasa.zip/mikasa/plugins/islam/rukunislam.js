exports.default = {
    names: ['Islam'],
    tags: ['rukunislam'],
    command: ['rukunislam'],
    start: async (m, { conn, text, prefix, command }) => {
        const pesan = `*RUKUN ISLAM*\n\n` +
                      `Rukun Islam adalah lima pilar utama dalam agama Islam yang menjadi dasar bagi ibadah dan ketaatan seorang Muslim. Kelima rukun tersebut adalah:\n\n` +
                      `*1. Syahadat (شهادة):*\n` +
                      `   - Mengucapkan dua kalimat syahadat:\n` +
                      `     أَشْهَدُ أَنْ لَا إِلَٰهَ إِلَّا ٱللَّٰهُ\n` +
                      `     Latin: Asyhadu an laa ilaaha illallaah\n` +
                      `     Arti: Aku bersaksi bahwa tidak ada Tuhan selain Allah.\n` +
                      `   - Dan:\n` +
                      `     وَأَشْهَدُ أَنَّ مُحَمَّدًا رَسُولُ ٱللَّٰهِ\n` +
                      `     Latin: Wa asyhadu anna Muhammadar rasuulullaah\n` +
                      `     Arti: Dan aku bersaksi bahwa Muhammad adalah utusan Allah.\n` +
                      `   - Syahadat merupakan pintu masuk ke dalam agama Islam.\n\n` +
                      `*2. Sholat (صلاة):*\n` +
                      `   - Mendirikan sholat lima waktu sehari semalam (Subuh, Dzuhur, Ashar, Maghrib, Isya).\n` +
                      `   - Sholat adalah ibadah wajib yang merupakan tiang agama dan sarana komunikasi langsung antara hamba dengan Allah.\n\n` +
                      `*3. Zakat (زكاة):*\n` +
                      `   - Menunaikan zakat, yaitu memberikan sebagian harta yang telah mencapai nisab dan haul kepada yang berhak menerimanya (fakir, miskin, amil zakat, dll.).\n` +
                      `   - Zakat adalah ibadah sosial dan bentuk kepedulian terhadap sesama.\n\n` +
                      `*4. Puasa (صوم):*\n` +
                      `   - Berpuasa wajib di bulan Ramadhan, yaitu menahan diri dari makan, minum, dan segala sesuatu yang membatalkan puasa mulai dari terbit fajar hingga terbenam matahari.\n` +
                      `   - Puasa melatih kesabaran, pengendalian diri, dan meningkatkan ketakwaan.\n\n` +
                      `*5. Haji (حج):*\n` +
                      `   - Menunaikan ibadah haji ke Baitullah (Ka'bah) di Mekah bagi yang mampu secara fisik dan finansial.\n` +
                      `   - Haji merupakan puncak ibadah dan persatuan umat Islam dari seluruh dunia.\n\n` +
                      `Melaksanakan kelima rukun Islam ini adalah kewajiban bagi setiap Muslim yang memenuhi syarat dan merupakan fondasi utama dalam menjalankan ajaran agama Islam.`;

        m.reply(pesan);
    },
};
