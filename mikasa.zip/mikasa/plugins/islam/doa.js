const daftarDoa = [
  "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ",
  "Robbanaa aatinaa fiddunyaa hasanah, wa fil aakhiroti hasanah, wa qinaa 'adzaaban naar.",
  "(Ya Tuhan kami, berilah kami kebaikan di dunia dan kebaikan di akhirat, dan peliharalah kami dari siksa neraka.) (QS. Al-Baqarah: 201)",

  "رَبَّنَا لَا تُؤَاخِذْنَا إِنْ نَسِينَا أَوْ أَخْطَأْنَا",
  "Robbanaa laa tu-aakhidznaa in nasiinaa au akhtho-naa.",
  "(Ya Tuhan kami, janganlah Engkau hukum kami jika kami lupa atau kami melakukan kesalahan.) (QS. Al-Baqarah: 286)",

  "رَبَّنَا وَلَا تَحْمِلْ عَلَيْنَا إِصْرًا كَمَا حَمَلْتَهُ عَلَى الَّذِينَ مِنْ قَبْلِنَا",
  "Robbanaa walaa tahmil 'alainaa ishran kamaa hamaltahuu 'alal ladziina min qoblinaa.",
  "(Ya Tuhan kami, janganlah Engkau bebankan kepada kami beban yang berat sebagaimana Engkau bebankan kepada orang-orang sebelum kami.) (QS. Al-Baqarah: 286)",

  "رَبَّنَا وَلَا تُحَمِّلْنَا مَا لَا طَاقَةَ لَنَا بِهِ وَاعْفُ عَنَّا وَاغْفِرْ لَنَا وَارْحَمْنَا أَنْتَ مَوْلَانَا فَانْصُرْنَا عَلَى الْقَوْمِ الْكَافِرِينَ",
  "Robbanaa walaa tuhammilnaa maa laa thooqota lanaa bih, wa'fu 'annaa, waghfir lanaa, warhamnaa, anta maulaanaa fanshurnaa 'alal qoumil kaafiriin.",
  "(Ya Tuhan kami, janganlah Engkau pikulkan kepada kami apa yang tak sanggup kami memikulnya. Beri maaflah kami; ampunilah kami; dan rahmatilah kami. Engkaulah Penolong kami, maka tolonglah kami terhadap kaum yang kafir.) (QS. Al-Baqarah: 286)",

  "رَبَّنَا لَا تُزِغْ قُلُوبَنَا بَعْدَ إِذْ هَدَيْتَنَا وَهَبْ لَنَا مِنْ لَدُنْكَ رَحْمَةً إِنَّكَ أَنْتَ الْوَهَّابُ",
  "Robbanaa laa tuzigh quluubanaa ba'da idz hadaitanaa wahab lanaa min ladunka rohmah, innaka antal wahhaab.",
  "(Ya Tuhan kami, janganlah Engkau condongkan hati kami kepada kesesatan setelah Engkau berikan petunjuk kepada kami, dan karuniakanlah kepada kami rahmat dari sisi-Mu; karena sesungguhnya Engkau-lah Maha Pemberi (karunia).) (QS. Ali Imran: 8)",

  "رَبَّنَا هَبْ لَنَا مِنْ أَزْوَاجِنَا وَذُرِّيَّاتِنَا قُرَّةَ أَعْيُنٍ وَاجْعَلْنَا لِلْمُتَّقِينَ إِمَامًا",
  "Robbanaa hab lanaa min azwaajinaa wa dzurriyyaatinaa qurrota a'yun waj'alnaa lil muttaqiina imaamaa.",
  "(Ya Tuhan kami, anugerahkanlah kepada kami istri-istri kami dan keturunan kami sebagai penyenang hati (kami), dan jadikanlah kami imam bagi orang-orang yang bertakwa.) (QS. Al-Furqan: 74)",

  "اَللَّهُمَّ إِنِّيْ أَعُوْذُ بِكَ مِنْ عَذَابِ جَهَنَّمَ وَمِنْ عَذَابِ الْقَبْرِ وَمِنْ فِتْنَةِ الْمَحْيَا وَالْمَمَاتِ وَمِنْ شَرِّ فِتْنَةِ الْمَسِيْحِ الدَّجَّالِ",
  "Allahumma innii a'uudzubika min 'adzaabi jahannam, wa min 'adzaabil qobri, wa min fitnatil mahyaa wal mamaati, wa min syarri fitnatil masiihid dajjaal.",
  "(Ya Allah, sesungguhnya aku berlindung kepada-Mu dari siksa neraka Jahannam, dari siksa kubur, dari fitnah kehidupan dan kematian, dan dari kejahatan fitnah Al-Masih Ad-Dajjal.) (HR. Muslim)",

  "اَللَّهُمَّ إِنِّيْ أَعُوْذُ بِكَ مِنْ شَرِّ مَا عَمِلْتُ وَمِنْ شَرِّ مَا لَمْ أَعْمَلْ",
  "Allahumma innii a'uudzubika min syarri maa 'amiltu wa min syarri maa lam a'mal.",
  "(Ya Allah, sesungguhnya aku berlindung kepada-Mu dari keburukan perbuatanku dan dari keburukan apa yang belum aku perbuat.) (HR. Muslim)",

  "اَللَّهُمَّ أَصْلِحْ لِيْ دِيْنِيْ الَّذِيْ هُوَ عِصْمَةُ أَمْرِيْ، وَأَصْلِحْ لِيْ دُنْيَايَ الَّتِيْ فِيْهَا مَعَاشِيْ، وَأَصْلِحْ لِيْ آخِرَتِيْ الَّتِيْ إِلَيْهَا مَعَادِيْ، وَاجْعَلِ الْحَيَاةَ زِيَادَةً لِيْ فِيْ كُلِّ خَيْرٍ، وَالْمَوْتَ رَاحَةً لِيْ مِنْ كُلِّ شَرٍّ",
  "Allahumma ashlih lii diiniyalladzii huwa 'ishmatu amrii, wa ashlih lii dunyaayallatii fiihaa ma'aasyii, wa ashlih lii aakhirotillatii ilaihaa ma'aadii, waj'alil hayaata ziyaadatan lii fii kulli khoir, wal mauta roohatan lii min kulli syarr.",
  "(Ya Allah, perbaikilah bagiku agamaku yang merupakan penjaga urusanku, perbaikilah bagiku duniaku yang di dalamnya terdapat kehidupanku, perbaikilah bagiku akhiratku yang kepadanya aku kembali, jadikanlah kehidupanku ini sebagai tambahan bagiku dalam setiap kebaikan, dan jadikanlah kematianku sebagai istirahat bagiku dari segala keburukan.) (HR. Muslim)",

  "اَللَّهُمَّ إِنِّيْ أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِيْ دِيْنِيْ وَدُنْيَايَ وَأَهْلِيْ وَمَالِيْ",
  "Allahumma innii as-alukal 'afwa wal 'aafiyah fii diinii wa dunyaaya wa ahlii wa maalii.",
  "(Ya Allah, sesungguhnya aku memohon kepada-Mu ampunan dan keselamatan dalam agamaku, duniaku, keluargaku, dan hartaku.) (HR. Abu Dawud dan Ibnu Majah)",

  // Tambahkan doa-doa lainnya di sini
  "يَا مُقَلِّبَ الْقُلُوبِ ثَبِّتْ قَلْبِي عَلَى دِينِكَ",
  "Yaa muqollibal quluub tsabbit qolbii 'alaa diinik.",
  "(Wahai Dzat yang membolak-balikkan hati, teguhkanlah hatiku di atas agama-Mu.) (HR. Tirmidzi)",

  "اَللَّهُمَّ أَعِنِّيْ عَلَى ذِكْرِكَ وَشُكْرِكَ وَحُسْنِ عِبَادَتِكَ",
  "Allahumma a'innii 'alaa dzikrika wa syukrika wa husni 'ibaadatik.",
  "(Ya Allah, tolonglah aku untuk berdzikir kepada-Mu, bersyukur kepada-Mu, dan beribadah kepada-Mu dengan baik.) (HR. Abu Dawud dan An-Nasa'i)",

  "اَللَّهُمَّ اغْفِرْ لِيْ ذَنْبِيْ كُلَّهُ دِقَّهُ وَجِلَّهُ وَأَوَّلَهُ وَآخِرَهُ وَعَلَانِيَتَهُ وَسِرَّهُ",
  "Allahummaghfir lii dzanbii kullahu diqqahuu wa jillahuu wa awwalahuu wa aakhirohuu wa 'alaaniyatahuu wa sirrohuu.",
  "(Ya Allah, ampunilah seluruh dosaku, yang kecil maupun yang besar, yang pertama maupun yang terakhir, yang tampak maupun yang tersembunyi.) (HR. Muslim)",

  "اَللَّهُمَّ إِنِّيْ ظَلَمْتُ نَفْسِيْ ظُلْمًا كَثِيْرًا وَلَا يَغْفِرُ الذُّنُوْبَ إِلَّا أَنْتَ فَاغْفِرْ لِيْ مَغْفِرَةً مِنْ عِنْدِكَ وَارْحَمْنِيْ إِنَّكَ أَنْتَ الْغَفُوْرُ الرَّحِيْمُ",
  "Allahumma innii zholamtu nafsii zhulman katsiiraa walaa yaghfirudz dzunuuba illaa anta faghfir lii maghfirotan min 'indika warhamnii innaka antal ghofuurur rohiim.",
  "(Ya Allah, sesungguhnya aku telah menzalimi diriku sendiri dengan kezaliman yang banyak, dan tidak ada yang dapat mengampuni dosa-dosa kecuali Engkau. Maka ampunilah aku dengan ampunan dari sisi-Mu dan rahmatilah aku. Sesungguhnya Engkau Maha Pengampun lagi Maha Penyayang.) (HR. Bukhari dan Muslim)",

  "اَللَّهُمَّ إِنِّيْ أَعُوْذُ بِكَ مِنْ جَهْدِ الْبَلَاءِ وَدَرَكِ الشَّقَاءِ وَسُوْءِ الْقَضَاءِ وَشَمَاتَةِ الْأَعْدَاءِ",
  "Allahumma innii a'uudzubika min jahdil balaa-i, wa darakisy syaqoo-i, wa suu-il qodhoo-i, wa syamaatatil a'daa-i.",
  "(Ya Allah, sesungguhnya aku berlindung kepada-Mu dari beratnya cobaan, dari kesempitan kesengsaraan, dari buruknya takdir, dan dari kegembiraan musuh atas kesusahanku.) (HR. Bukhari dan Muslim)",

  "اَللَّهُمَّ اكْفِنِيْ بِحَلَالِكَ عَنْ حَرَامِكَ وَأَغْنِنِيْ بِفَضْلِكَ عَمَّنْ سِوَاكَ",
  "Allahummakfinii bihalaalika 'an haraamik, wa aghninii bifadhlika 'amman siwaak.",
  "(Ya Allah, cukupkanlah aku dengan yang halal dari-Mu, sehingga aku tidak membutuhkan yang haram, dan kayakanlah aku dengan karunia-Mu, sehingga aku tidak membutuhkan selain-Mu.) (HR. Tirmidzi)",

  "اَللَّهُمَّ إِنِّيْ أَسْأَلُكَ عِلْمًا نَافِعًا وَرِزْقًا طَيِّبًا وَعَمَلًا مُتَقَبَّلًا",
  "Allahumma innii as-aluka 'ilman naafi'aa, wa rizqon thoyyibaa, wa 'amalan mutaqobbalaa.",
  "(Ya Allah, sesungguhnya aku memohon kepada-Mu ilmu yang bermanfaat, rezeki yang baik, dan amal yang diterima.) (HR. Ibnu Majah)",

  "اَللَّهُمَّ ارْحَمْنِيْ بِرَحْمَتِكَ الْوَاسِعَةِ",
  "Allahummar hamnii birahmatikal waasi'ah.",
  "(Ya Allah, rahmatilah aku dengan rahmat-Mu yang luas.)",

  "اَللَّهُمَّ إِنِّيْ أَسْأَلُكَ الْجَنَّةَ وَأَعُوْذُ بِكَ مِنَ النَّارِ",
  "Allahumma innii as-alukal jannah wa a'uudzubika minan naar.",
  "(Ya Allah, sesungguhnya aku memohon kepada-Mu surga dan aku berlindung kepada-Mu dari neraka.)",

  "سُبْحَانَ اللهِ وَبِحَمْدِهِ سُبْحَانَ اللهِ الْعَظِيْمِ",
  "Subhaanallaahi wa bihamdihi subhaanallaahil 'azhiim.",
  "(Maha Suci Allah dan segala puji bagi-Nya, Maha Suci Allah Yang Maha Agung.) (HR. Bukhari dan Muslim)",

  "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللهِ",
  "Laa haula walaa quwwata illaa billaah.",
  "(Tidak ada daya dan kekuatan kecuali dengan pertolongan Allah.)",

  // Tambahkan lebih banyak doa lagi di sini jika Anda inginkan
];

exports.default = {
  names: ['Islam'],
  tags: ['doa','bacaandoa'],
  command: ['doa', 'bacaandoa'],
  start: async (m, { conn }) => {
    const randomIndex = Math.floor(Math.random() * daftarDoa.length / 3); // Karena setiap doa terdiri dari 3 elemen
    const index = randomIndex * 3;
    const doaArab = daftarDoa[index];
    const doaLatin = daftarDoa[index + 1];
    const artiDoa = daftarDoa[index + 2];

    const pesanDoa = `*Bacaan Doa:*\n${doaArab}\n\n*Latin:*\n${doaLatin}\n\n*Arti:*\n${artiDoa}`;

    await conn.sendMessage(m.chat, { text: pesanDoa }, { quoted: m });
  },
};
