const express = require('express');
const axios = require('axios');
const cheerio = require('cheerio');
const app = express();
const cors = require('cors');

app.use(cors());

app.get('/api/jadwal', async (req, res) => {
  const { dari, ke, tanggal } = req.query;
  if (!dari || !ke || !tanggal) return res.status(400).json({ error: 'Missing parameters' });

  try {
    const url = `https://en.keretaapi.info/?dari=${dari}&ke=${ke}&tanggal=${tanggal}`;
    const response = await axios.get(url);
    const $ = cheerio.load(response.data);

    const jadwal = [];

    $('table#tjadwal tr').each((i, el) => {
      const td = $(el).find('td');
      if (td.length >= 5) {
        jadwal.push({
          nama_kereta: td.eq(0).text().trim(),
          berangkat: td.eq(1).text().trim(),
          tiba: td.eq(2).text().trim(),
          durasi: td.eq(3).text().trim(),
          kelas: td.eq(4).text().trim()
        });
      }
    });

    res.json({ rute: `${dari} - ${ke}`, tanggal, data: jadwal });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Gagal mengambil data' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Proxy API aktif di http://localhost:${PORT}`));