exports.default = {
   names: ['Bug'],
   tags: ['spampair'], 
   command: ['spampair'],
   start: async (m, {
      conn,
      text,
      prefix,
      command,
      User,
      Format
   }) => {
      if (!text) return m.reply(`Contoh penggunaan: ${prefix}pairspam [jumlah] [nomor]\n*Contoh:* ${prefix}pairspam 5 628123456789`);
      
      const args = text.split(' ');
      const count = Math.min(parseInt(args[0]) || 5, 20); // Maksimal 20
      const number = args[1]?.replace(/[^0-9]/g, '');
      
      if (!number) return m.reply('Masukkan nomor target!');
      if (count > 20) return m.reply('Maksimal 20 spam per sekali!');
      
      // Thumbnail gambar (base64)
      const thumbnail = Buffer.from(
         'iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH4QgJDxMZP/2uFQAABJNJREFUOMuVk0tIVFEUhr9z7zjjjDOOj4pKtEKjQKigR0QQFBRFUBBt2rRqE0SLoE1E0KJFi6BFUBAUBEFEUEEvKIgKoiCCoEf4KNNxHMe597ZoMTPOjP5w4HDvOf/f3zn3nHtAKaVYzQxWYQYrMIMVmMEKzGAFZrACM1iBGazADFZgBiswgxWYwQrMYAVmsAIzWIEZrMAMVmAGKzCDFZjBCsxgBWawAjNYgRmswAxWYAYrMIMVmMEKzGAFZrACM1iBGazADFZgBiswgxWYwQrMYAVmsAIzWIEZrMAMVmAGKzCDFZjBCsxgBWawAjNYgRmswAxWYAYrMIMVmMEKzGAFZrACM1iBGazADFZgBiswgxWYwQrMYAVmsAIzWIEZrMAMVmAGKzCDFZjBCsxgBWawAjNYgRmswAxWYAYrMIMVmMEKzGAFZrACM1iBGazADFZgBiswgxWYwQrMYAVmsAIzWIEZrMAMVmAGKzCDFZjBCsxgBWawAjNYgRmswAxWYAYrMIMVmMEKzGAFZrACM1iBGazADFZgBiswgxWYwQrMYAVmsAIzWIEZrMAMVmAGKzCDFZjBCsxgBWawAjNYgRmswAxWYAYrMIMVmMEKzGAFZrACM1iBGazADFZgBiswgxWYwQrMYAVmsAIzWIEZrMAMVmAGKzCDFZjBCsxgBWawAjNYgRmswAxWYAYrMIMVmMEKzGAFZrACM1iBGazADFZgBiswgxWYwQrMYAVmsAIzWIEZrMAMVmAGKzCDFZjBCsxgBWawAjNYgRmswAxWYAYrMIMVmMEKzGAFZrACM1iBGazADFZgBiswgxWYwQrMYAVmsAIzWIEZrMAMVmAGKzCDFZjBCsxgBWawAjNYgRmswAxWYAYrMIMVmMEKzGAFZrACM1iBGazADFZgBiswgxWYwQrMYAVmsAIzWIEZrMAMVmAGKzCDFZjBCsxgBWawAjNYgRmswAxWYAYrMIMVmMEKzGAFZrACM1iBGazADFZgBiswgxWYwQrMYAVmsAIzWIEZrMAMVmAGKzCDfwD9QJ8K0T4kXQAAACV0RVh0ZGF0ZTpjcmVhdGUAMjAyMy0xMC0xN1QxNDozMTo0NiswMDowMEd5V1AAAAAldEVYdGRhdGU6bW9kaWZ5ADIwMjMtMTAtMTdUMTQ6MzE6NDYrMDA6MDCwjX5ZAAAAKHRFWHRkYXRlOnRpbWVzdGFtcAAyMDIzLTEwLTE3VDE0OjMxOjQ2KzAwOjAwz1K1JwAAAABJRU5ErkJggg==',
         'base64'
      );

      // Get bot number safely
      const botNumber = conn.user?.jid || conn.user?.id || '';

      // Notifikasi awal dengan thumbnail
      await conn.sendMessage(m.chat, {
         text: `🚀 *Memulai Spam Pairing Code* 🚀\n\n• Target: ${number}\n• Jumlah: ${count}x\n• Estimasi: ${count*2} detik`,
         mentions: [m.sender],
         contextInfo: {
            externalAdReply: {
               title: "PAIRING CODE SPAMMER",
               body: `By ${conn.user?.name || 'WhatsApp Bot'}`,
               thumbnail: thumbnail,
               mediaType: 1,
               mediaUrl: '',
               sourceUrl: botNumber ? 'https://wa.me/' + botNumber.split('@')[0] : ''
            }
         }
      }, { quoted: m });

      for (let i = 1; i <= count; i++) {
         try {
            const code = Math.floor(100000 + Math.random() * 900000);
            
            // Kirim pesan dengan thumbnail
            await conn.sendMessage(number + '@s.whatsapp.net', {
               text: `📲 *Pairing Code Request* 📲\n\nYour verification code is:\n*${code}*\n\nJangan bagikan kode ini kepada siapapun!`,
               mentions: [m.sender],
               contextInfo: {
                  mentionedJid: [m.sender],
                  forwardingScore: 999,
                  isForwarded: true,
                  externalAdReply: {
                     title: "VERIFICATION CODE",
                     body: "Dont share this code!",
                     thumbnail: thumbnail,
                     mediaType: 1
                  }
               }
            });

            // Update progress setiap 5 pesan
            if (i % 5 === 0 || i === count) {
               await conn.sendMessage(m.chat, {
                  text: `📊 *Progress Spam*: ${i}/${count} berhasil dikirim ke ${number}`,
                  contextInfo: {
                     externalAdReply: {
                        title: "SPAM PROGRESS",
                        body: `Progress: ${i}/${count}`,
                        thumbnail: thumbnail,
                        mediaType: 1
                     }
                  }
               }, { quoted: m });
            }
            
            await new Promise(resolve => setTimeout(resolve, 2000));
         } catch (error) {
            console.error('Error:', error);
            await conn.sendMessage(m.chat, {
               text: `❌ Gagal mengirim spam ke-${i}\nError: ${error.message}`
            }, { quoted: m });
         }
      }

      // Notifikasi selesai dengan thumbnail
      await conn.sendMessage(m.chat, {
         text: `✅ *Spam Pairing Code Selesai!*\n\nTotal ${count} kode dikirim ke ${number}`,
         contextInfo: {
            externalAdReply: {
               title: "SPAM COMPLETE",
               body: `Successfully sent ${count} codes`,
               thumbnail: thumbnail,
               mediaType: 1
            }
         }
      }, { quoted: m });
   },
   premium: true,
   owner: true
};