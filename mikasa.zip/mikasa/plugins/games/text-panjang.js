exports.default = {
  names: ['buat trend'],
  tags: ['longtext','lt'],
  command: ['longtext','lt'],
  start: async (m, {
    conn,
    text,
    prefix,
    command,
    User,
    Format
  }) => {
    if (!text) return conn.reply(m.chat, `Contoh penggunaan:\n${prefix + command} aku cinta kamu | ❤️`, m);

    // Pisahkan teks dan emoji
    let [mainText, emoji] = text.split('|').map(v => v.trim());
    if (!mainText) return conn.reply(m.chat, `Teks tidak boleh kosong!\nContoh: ${prefix + command} aku cinta kamu | ❤️`, m);
    if (!emoji) emoji = '❤️'; // default jika tidak dikasih emoji

    let phrase = `${mainText} ${emoji}`;
    let output = '';
    let spaces = 0;
    let increasing = true;
    let maxSpace = 10;

    for (let i = 0; i < 1000; i++) {
      output += ' '.repeat(spaces) + phrase + '\n';

      if (increasing) {
        spaces++;
        if (spaces >= maxSpace) increasing = false;
      } else {
        spaces--;
        if (spaces <= 0) {
          spaces = 0;
          increasing = true;
        }
      }
    }

    await conn.reply(m.chat, output.trim(), m);
  },
  limit: false
};