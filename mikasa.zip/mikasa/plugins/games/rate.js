exports.default = {
   names: ['quotes'],
   tags: ['rate'],
   command: ['rate', 'ret'],
   start: async (m, {
      conn,
      text,
      prefix,
      command,
      User,
      Format
   }) => {
      // Menghasilkan nomor acak antara 50 dan 100 (inklusif)
      const randomNumber = Math.floor(Math.random() * (100 - 50 + 1)) + 50;

      // Kamu bisa menggunakan 'randomNumber' di sini untuk keperluan lain
      console.log(randomNumber);

      // Contoh bagaimana kamu bisa mengirim nomor acak ke pengguna:
      m.reply(`nilai: ${randomNumber}`, m.react('😃'));

      // kode kamu or your code selanjutnya bisa diletakkan di sini
   }
}
