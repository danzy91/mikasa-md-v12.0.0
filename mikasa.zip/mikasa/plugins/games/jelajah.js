const karakter = {}; // Objek untuk menyimpan data karakter sementara (pastikan ini terkelola di tempat lain jika Anda ingin data persisten)

// Fungsi untuk menghitung EXP yang dibutuhkan untuk level berikutnya (jika Anda ingin mempertahankan leveling)
function getExpNeeded(level) {
   return 50 * level * (level + 1);
}

exports.default = {
   names: ['RPG'],
   tags: ['jelajah'],
   command: ['jelajah'],
   start: async (m, {
      conn,
      text,
      prefix,
      command,
      User,
      Format,
      sender
   }) => {
      if (!karakter[sender]) {
         return m.reply('Kamu belum memulai petualangan. Buat karakter terlebih dahulu (gunakan perintah yang sesuai di plugin utama RPG Anda).');
      }

      const char = karakter[sender];
      const hasil = Math.random();
      let pesan = `${char.nama} memulai penjelajahan...`;

      if (hasil < 0.25) {
         const expGain = Math.floor(Math.random() * 25) + 10;
         karakter[sender].exp += expGain;
         pesan += `\n✨ Kamu menemukan sesuatu yang berharga dan mendapatkan ${expGain} EXP!`;
      } else if (hasil < 0.5) {
         const enemyAttack = Math.floor(Math.random() * 12) + 8;
         const damageTaken = Math.max(0, enemyAttack - (char.defense || 0)); // Asumsi karakter mungkin punya defense
         karakter[sender].hp -= damageTaken;
         pesan += `\n👾 Kamu bertemu makhluk liar dan terkena serangan sebesar ${damageTaken} damage. (Sisa HP: ${char.hp})`;
         if (karakter[sender].hp <= 0) {
            karakter[sender].hp = 0;
            pesan += `\n💀 ${char.nama} terluka parah! (HP: 0).`;
            // Anda mungkin ingin menghapus karakter di sini jika HP 0 dan tidak ada sistem kebangkitan
            // delete karakter[sender];
         }
      } else if (hasil < 0.75) {
         pesan += `\n🍃 Kamu menjelajahi sekitar dan tidak menemukan apa-apa yang menarik.`;
      } else {
         const healAmount = Math.floor(Math.random() * 18) + 7;
         karakter[sender].hp += healAmount;
         pesan += `\n❤️ Kamu menemukan sumber air jernih dan memulihkan ${healAmount} HP. (Sisa HP: ${char.hp})`;
      }

      // Cek level up (opsional, jika Anda ingin mempertahankan leveling di plugin ini)
      if (karakter[sender] && karakter[sender].exp >= (karakter[sender].expNeeded || getExpNeeded(char.level || 1))) {
         karakter[sender].level = (karakter[sender].level || 0) + 1;
         karakter[sender].exp -= (karakter[sender].expNeeded || getExpNeeded(char.level - 1));
         karakter[sender].expNeeded = getExpNeeded(karakter[sender].level);
         karakter[sender].hp = 100 + (karakter[sender].level - 1) * 10;
         karakter[sender].attack = (karakter[sender].attack || 10) + 5;
         karakter[sender].defense = (karakter[sender].defense || 5) + 2;
         pesan += `\n⬆️ Selamat! Kamu naik level menjadi Level ${karakter[sender].level}!\nStatistikmu meningkat!`;
      }

      m.reply(pesan);
   }
};
