exports.default = {
   names: ['Games'],
   tags: ['hitungkata'],
   command: ['hitungkata', 'hita'],
   start: async (m, {
      conn,
      text,
      prefix,
      command
   }) => {
      if (!text) {
         return m.reply(`Silakan kirim pesan yang ingin dihitung katanya!\nContoh: ${prefix}${command} Halo dunia yang indah`);
      }

      const jumlahKata = text.split(/\s+/).filter(Boolean).length;
      const responsAcak = [
         `Wow, pesanmu terdiri dari ${jumlahKata} kata! Sangat efisien!`,
         `Pesanmu memiliki ${jumlahKata} kata. Cukup ringkas.`,
         `Ada ${jumlahKata} kata dalam pesan ini. Menarik!`,
         `Hanya ${jumlahKata} kata? Singkat dan padat!`,
         `Pesan sepanjang ${jumlahKata} kata. Lumayan panjang juga ya.`,
         `Terdiri dari ${jumlahKata} kata. Semoga isinya bermakna!`,
         `Jumlah kata: ${jumlahKata}. Semoga harimu menyenangkan!`,
         `Pesan dengan ${jumlahKata} kata. Terima kasih sudah berbagi!`,
         `Ada ${jumlahKata} kata di sini. Jangan lupa tersenyum!`,
         `${jumlahKata} kata terhitung. Semangat terus!`,
      ];
      const randomIndex = Math.floor(Math.random() * responsAcak.length);
      m.reply(responsAcak[randomIndex]);
   },
   limit: false // Tidak perlu limit karena ini fitur ringan
}
