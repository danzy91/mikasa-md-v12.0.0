exports.default = {
    names: ['Games'],
    tags: ['hama'],
    command: ['hama'],
    start: async (m, { conn, text, prefix, command }) => {
        if (command === 'hama') {
            if (text) {
                m.reply(`${text} : hama`);
            } else {
                m.reply('Silakan masukkan teks setelah perintah .hama\nContoh: .hama keren');
            }
        }
    },
};
