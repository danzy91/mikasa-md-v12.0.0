exports.default = {
   names: ['Games'],
   tags: ['crypto'],
   command: ['crypto'],
   start: async (m, {
      conn,
      text,
      prefix,
      command
   }) => {
      if (!text) return m.reply(`Contoh: ${prefix}crypto bitcoin`);
      
      try {
         const coin = text.toLowerCase().trim();
         const apiUrl = `https://api.coingecko.com/api/v3/coins/${coin}`;
         const response = await fetch(apiUrl);
         
         if (!response.ok) throw new Error('Koin tidak ditemukan atau API error!');
         
         const data = await response.json();
         const { 
            name, 
            symbol, 
            market_data: { 
               current_price, 
               price_change_percentage_24h,
               market_cap 
            },
            last_updated,
            image
         } = data;
         
         const updatedTime = new Date(last_updated).toLocaleString();
         const priceUSD = current_price.usd.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
         const change24h = price_change_percentage_24h.toFixed(2);
         const marketCap = market_cap.usd.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
         
         // Fix: Handle thumbnail properly
         let thumbnail;
         try {
            const imgResponse = await fetch(image.small);
            thumbnail = await imgResponse.arrayBuffer();
         } catch (e) {
            thumbnail = null; // Skip thumbnail if error
         }
         
         const caption = `📊 *${name} (${symbol.toUpperCase()})*\n\n` +
                         `💵 Harga: ${priceUSD}\n` +
                         `📈 24h Change: ${change24h}%\n` +
                         `🏦 Market Cap: ${marketCap}\n` +
                         `⏰ Update: ${updatedTime}`;
         
         const msgOptions = {
            text: caption,
            ...(thumbnail && {
               contextInfo: { 
                  externalAdReply: {
                     title: `💰 ${name} Price Tracker`,
                     body: `Update: ${updatedTime}`,
                     thumbnail: Buffer.from(thumbnail),
                     sourceUrl: `https://www.coingecko.com/en/coins/${coin}`
                  }
               }
            })
         };
         
         conn.sendMessage(m.chat, msgOptions);
         
      } catch (error) {
         m.reply(`🚨 Error: ${error.message}\nContoh penggunaan: ${prefix}crypto bitcoin`);
      }
   },
   limit: true
};