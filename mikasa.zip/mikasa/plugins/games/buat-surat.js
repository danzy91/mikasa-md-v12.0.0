exports.default = {
   names: ['Games'],
   tags: ['kirimsurat'],
   command: ['kirimsurat'],
   start: async (m, {
      conn,
      text,
      prefix,
      command,
      User,
      Format
   }) => {
      if (!text) {
         return m.reply(`Penggunaan: ${prefix}${command} <nomor tujuan>/<gaya>/<judul>/<isi surat>\n\n*Pilihan Gaya:*\n1. Estetik Banget (Contoh)\n2. Minimalis Garis\n3. Sentuhan Bunga\n4. Modern Blok\n5. Simpel Elegan\n\nContoh: ${prefix}${command} 628xxxxxxxxx/1/Pesan Singkat/Hai, apa kabar?`);
      }

      const args = text.split('/');
      const targetNumber = args[0]?.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
      const styleChoice = parseInt(args[1]);
      const letterTitle = args[2]?.trim();
      const letterContent = args.slice(3).join('/').trim();

      if (!targetNumber || isNaN(styleChoice) || !letterTitle || !letterContent) {
         return m.reply(`Format tidak valid. Gunakan: ${prefix}${command} <nomor tujuan>/<gaya>/<judul>/<isi surat>\n\n*Pilihan Gaya:*\n1. Estetik Banget (Contoh)\n2. Minimalis Garis\n3. Sentuhan Bunga\n4. Modern Blok\n5. Simpel Elegan`);
      }

      if (letterContent.length > 1000) {
         return m.reply('Isi surat terlalu panjang.');
      }

      let aestheticLetter;

      switch (styleChoice) {
         case 1:
            aestheticLetter = `
ೋೋ═══ 📜 ═══ೋೋ
        🌸 *${letterTitle.toUpperCase()}* 🌸
·•·•·•·•·•·•·•·•·•·•·•·•·•·•·•·•·•·•·•·

🗓️ Tanggal: ${typeof Format === 'object' && typeof Format.date === 'function' ? Format.date('DD MMMM YYYY') : new Date().toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric' })}
🕰️ Waktu: ${typeof Format === 'object' && typeof Format.date === 'function' ? Format.date('HH.mm.ss') : new Date().toLocaleTimeString('id-ID', { hour: 'numeric', minute: 'numeric', second: 'numeric' })}
👤 Dari: ${m.pushName || 'Pengirim'}

🕊️ Kepada Yth. @${targetNumber.split('@')[0]},

    ${letterContent}

💐 Dengan hormat,

    ${m.pushName || 'Pengirim'}
·•·•·•·•·•·•·•·•·•·•·•·•·•·•·•·•·•·•·•·
ೋೋ═══ 🖋️ ═══ೋೋ
    `;
            break;
         case 2:
            aestheticLetter = `
╭─────────── 💌 ───────────╮
   **${letterTitle}**
╰───────────────────────╯

Kepada Yth. ${targetNumber.split('@')[0]},

${letterContent}

---
Dikirim oleh: ${m.pushName || 'Pengirim'}
Tanggal: ${typeof Format === 'object' && typeof Format.date === 'function' ? Format.date('YYYY-MM-DD HH:mm') : new Date().toLocaleString()}
`;
            break;
         case 3:
            aestheticLetter = `
🌸°•.✿.•°🌸°•.✿.•°🌸

   **${letterTitle}**

Untuk: ${targetNumber.split('@')[0]}

${letterContent}

🌸°•.✿.•°🌸°•.✿.•°🌸

Salam hangat dari ${m.pushName || 'Pengirim'}
${typeof Format === 'object' && typeof Format.date === 'function' ? Format.date('dd/MM/yyyy') : new Date().toLocaleDateString()}
`;
            break;
         case 4:
            aestheticLetter = `
░▒▓█►──═<✨>═──◄█▓▒░

   **${letterTitle}**

Penerima: ${targetNumber.split('@')[0]}

${letterContent}

░▒▓█►──═<💫>═──◄█▓▒░

Dari: ${m.pushName || 'Pengirim'} - ${typeof Format === 'object' && typeof Format.date === 'function' ? Format.date('D MMM YYYY') : new Date().toLocaleDateString()}
`;
            break;
         case 5:
            aestheticLetter = `
✧･ﾟ: *✧･ﾟ:* 💌 *:･ﾟ✧*:･ﾟ✧

   **${letterTitle}**

Hai ${targetNumber.split('@')[0]},

${letterContent}

✧･ﾟ: *✧･ﾟ:* 🖋️ *:･ﾟ✧*:･ﾟ✧

-${m.pushName || 'Pengirim'}-
${typeof Format === 'object' && typeof Format.date === 'function' ? Format.date('dddd, DD MMMM YYYY') : new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
`;
            break;
         default:
            return m.reply(`Gaya surat tidak valid. Pilih antara 1 sampai 5.\n\n*Pilihan Gaya:*\n1. Estetik Banget (Contoh)\n2. Minimalis Garis\n3. Sentuhan Bunga\n4. Modern Blok\n5. Simpel Elegan`);
      }

      try {
         await conn.sendMessage(targetNumber, { text: aestheticLetter });
         m.reply(`✉️ Surat dengan gaya ${styleChoice} berjudul "${letterTitle}" berhasil dikirim ke ${targetNumber.split('@')[0]}!`);
      } catch (error) {
         console.error(error);
         m.reply('Maaf, gagal mengirim surat. Pastikan nomor tujuan benar.');
      }
   }
};
