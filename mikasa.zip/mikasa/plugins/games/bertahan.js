const karakterBertahan = {}; // Objek untuk menyimpan data karakter bertahan sementara

// Fungsi untuk menghasilkan angka acak dalam rentang tertentu
function getRandom(min, max) {
   return Math.floor(Math.random() * (max - min + 1)) + min;
}

const sumberDayaAwal = {
   kayu: 10,
   batu: 5,
   makanan: 5, // Representasi sederhana, bisa dipecah jadi jenis makanan
   air: 5
};

const kebutuhanPerHari = {
   makanan: 1,
   air: 1
};

exports.default = {
   names: ['RPG'],
   tags: ['mulai', 'statusku', 'kumpulkan', 'buatitem'],
   command: ['mulai', 'statusku', 'kumpulkan', 'buatitem'],
   start: async (m, {
      conn,
      text,
      prefix,
      command,
      User,
      Format,
      sender
   }) => {
      if (command === 'mulai') {
         if (karakterBertahan[sender]) {
            return m.reply('Kamu sudah memulai petualangan bertahan hidupmu!');
         }
         const nama = text ? text : 'Penyintas';
         karakterBertahan[sender] = {
            nama: nama,
            hp: 100,
            lokasi: 'Hutan Belantara',
            hariBertahan: 1,
            sumberDaya: { ...sumberDayaAwal }, // Salin sumber daya awal
            item: [] // Inventaris item
         };
         m.reply(`Selamat datang, ${nama}, di Hutan Belantara! Tujuanmu adalah bertahan hidup.\nKetik ${prefix}statusku untuk melihat kondisimu.`);
      } else if (command === 'statusku') {
         if (!karakterBertahan[sender]) {
            return m.reply('Kamu belum memulai petualangan bertahan hidup. Ketik ${prefix}mulai [nama] untuk memulainya.');
         }
         const char = karakterBertahan[sender];
         const sumberDayaText = Object.entries(char.sumberDaya)
            .map(([key, value]) => `${key}: ${value}`)
            .join(', ');
         const itemText = char.item.length > 0 ? char.item.join(', ') : 'Kosong';
         const statusText = `👤 Nama: ${char.nama}\n❤️ HP: ${char.hp}\n📍 Lokasi: ${char.lokasi}\n🗓️ Hari Bertahan: ${char.hariBertahan}\n📦 Sumber Daya: ${sumberDayaText}\n🎒 Item: ${itemText}`;
         m.reply(`=== Status Bertahan ===\n${statusText}`);
      } else if (command === 'kumpulkan') {
         if (!karakterBertahan[sender]) {
            return m.reply('Kamu belum memulai petualangan bertahan hidup. Ketik ${prefix}mulai [nama] untuk memulainya.');
         }
         const char = karakterBertahan[sender];
         const pilihan = text ? text.toLowerCase() : 'umum';
         let hasil = '';
         let sumberDayaDidapat = {};

         switch (pilihan) {
            case 'kayu':
               const kayuDidapat = getRandom(1, 3);
               char.sumberDaya.kayu += kayuDidapat;
               sumberDayaDidapat.kayu = kayuDidapat;
               hasil = `Kamu menebang pohon dan mendapatkan ${kayuDidapat} kayu.`;
               break;
            case 'batu':
               const batuDidapat = getRandom(0, 2);
               char.sumberDaya.batu += batuDidapat;
               sumberDayaDidapat.batu = batuDidapat;
               hasil = `Kamu mencari batu dan mendapatkan ${batuDidapat} batu.`;
               break;
            case 'makanan':
               const makananDidapat = getRandom(0, 1);
               char.sumberDaya.makanan += makananDidapat;
               sumberDayaDidapat.makanan = makananDidapat;
               hasil = `Kamu mencari makan dan mendapatkan ${makananDidapat} makanan.`;
               break;
            case 'air':
               const airDidapat = getRandom(0, 2);
               char.sumberDaya.air += airDidapat;
               sumberDayaDidapat.air = airDidapat;
               hasil = `Kamu mencari air dan mendapatkan ${airDidapat} air.`;
               break;
            default:
               const kemungkinan = Math.random();
               if (kemungkinan < 0.4) {
                  const kayuDidapat = getRandom(0, 1);
                  char.sumberDaya.kayu += kayuDidapat;
                  sumberDayaDidapat.kayu = kayuDidapat;
                  hasil = `Kamu mencari-cari dan mendapatkan ${kayuDidapat} kayu.`;
               } else if (kemungkinan < 0.7) {
                  const makananDidapat = getRandom(0, 1);
                  char.sumberDaya.makanan += makananDidapat;
                  sumberDayaDidapat.makanan = makananDidapat;
                  hasil = `Kamu mencari-cari dan mendapatkan ${makananDidapat} makanan.`;
               } else {
                  hasil = `Kamu menjelajahi sekitar tetapi tidak menemukan apa-apa.`;
               }
               break;
         }

         let pesan = `${char.nama} mencoba mengumpulkan sumber daya...\n${hasil}`;
         if (Object.keys(sumberDayaDidapat).length > 0) {
            pesan += `\nSumber daya saat ini: ${Object.entries(char.sumberDaya)
               .filter(([key]) => sumberDayaDidapat.hasOwnProperty(key))
               .map(([key, value]) => `${key}: ${value}`)
               .join(', ')}`;
         }

         // Simulasi kebutuhan harian (terjadi setiap kali mengumpulkan sumber daya untuk sederhana)
         char.sumberDaya.makanan -= kebutuhanPerHari.makanan;
         char.sumberDaya.air -= kebutuhanPerHari.air;
         if (char.sumberDaya.makanan < 0) char.hp -= 10; // Kelaparan
         if (char.sumberDaya.air < 0) char.hp -= 15; // Dehidrasi
         if (char.hp <= 0) {
            pesan += `\n${char.nama} kehabisan tenaga dan tidak selamat. Petualanganmu berakhir.`;
            delete karakterBertahan[sender];
         } else {
            char.hariBertahan++;
            pesan += `\nHari ke-${char.hariBertahan}...\nKebutuhan harian terpenuhi (sementara). Sisa HP: ${char.hp}`;
         }

         m.reply(pesan);
      } else if (command === 'buatitem') {
         if (!karakterBertahan[sender]) {
            return m.reply('Kamu belum memulai petualangan bertahan hidup. Ketik ${prefix}mulai [nama] untuk memulainya.');
         }
         const char = karakterBertahan[sender];
         const itemYangDibuat = text ? text.toLowerCase() : '';
         let hasil = '';

         switch (itemYangDibuat) {
            case 'kapak kayu':
               if (char.sumberDaya.kayu >= 5 && char.sumberDaya.batu >= 2) {
                  char.sumberDaya.kayu -= 5;
                  char.sumberDaya.batu -= 2;
                  char.item.push('kapak kayu');
                  hasil = 'Kamu berhasil membuat kapak kayu. Membantu menebang pohon lebih efisien.';
               } else {
                  hasil = 'Sumber daya tidak cukup untuk membuat kapak kayu (5 kayu, 2 batu).';
               }
               break;
            case 'tempat air':
               if (char.sumberDaya.kayu >= 3) {
                  char.sumberDaya.kayu -= 3;
                  char.item.push('tempat air sederhana');
                  hasil = 'Kamu berhasil membuat tempat air sederhana. Bisa menyimpan lebih banyak air.';
               } else {
                  hasil = 'Sumber daya tidak cukup untuk membuat tempat air (3 kayu).';
               }
               break;
            default:
               hasil = `Daftar item yang bisa dibuat (sementara):\n- kapak kayu (membutuhkan 5 kayu, 2 batu)\n- tempat air (membutuhkan 3 kayu)`;
               break;
         }

         m.reply(`${char.nama} mencoba membuat item...\n${hasil}`);
      }
   }
};
