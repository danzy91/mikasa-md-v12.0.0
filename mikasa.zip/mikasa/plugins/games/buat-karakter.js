const karakter = {}; // Objek untuk menyimpan data karakter sementara

exports.default = {
   names: ['RPG'],
   tags: ['buatkarakter', 'status', 'petualang'],
   command: ['buatkarakter', 'status', 'petualang'],
   start: async (m, {
      conn,
      text,
      prefix,
      command,
      User,
      Format,
      sender
   }) => {
      if (command === 'buatkarakter') {
         if (karakter[sender]) {
            return m.reply('Kamu sudah memiliki karakter!');
         }
         const nama = text ? text : 'Petualang';
         karakter[sender] = {
            nama: nama,
            level: 1,
            hp: 100,
            attack: 10,
            defense: 5,
            exp: 0
         };
         m.reply(`Selamat datang, ${nama}! Karaktermu telah dibuat.\nKetik ${prefix}status untuk melihat statusmu.`);
      } else if (command === 'status') {
         if (!karakter[sender]) {
            return m.reply('Kamu belum membuat karakter. Ketik ${prefix}buatkarakter [nama] untuk memulai.');
         }
         const char = karakter[sender];
         const statusText = `⚔️ Nama: ${char.nama}\nLevel: ${char.level}\n❤️ HP: ${char.hp}\n 공격: ${char.attack}\n🛡️ Pertahanan: ${char.defense}\n⭐ EXP: ${char.exp}`;
         m.reply(`=== Status Karakter ===\n${statusText}`);
      } else if (command === 'petualang') {
         if (!karakter[sender]) {
            return m.reply('Kamu belum membuat karakter. Ketik ${prefix}buatkarakter [nama] untuk memulai.');
         }
         // Contoh aksi petualangan sederhana
         const hasil = Math.random();
         if (hasil < 0.3) {
            karakter[sender].exp += 10;
            m.reply(`${karakter[sender].nama} menemukan sedikit pengalaman! (+10 EXP)`);
         } else if (hasil < 0.6) {
            m.reply(`${karakter[sender].nama} tidak menemukan apa-apa.`);
         } else {
            const damageTaken = Math.floor(Math.random() * 15);
            karakter[sender].hp -= damageTaken;
            if (karakter[sender].hp <= 0) {
               karakter[sender].hp = 0;
               m.reply(`${karakter[sender].nama} terluka parah dan pingsan! (HP: 0)`);
               delete karakter[sender]; // Hapus karakter jika HP 0 (sementara)
            } else {
               m.reply(`${karakter[sender].nama} menghadapi rintangan dan kehilangan ${damageTaken} HP. (Sisa HP: ${karakter[sender].hp})`);
            }
         }
      }
   }
};
