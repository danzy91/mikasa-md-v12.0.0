exports.default = {
  names: ['buat trend'],
  tags: ['textvertikal', 'tv'],
  command: ['teksvertikal', 'tv'],
  start: async (m, { conn, text }) => {
    if (!text) {
      return m.reply(`Penggunaan: ${m.prefix}${m.command} <teks>\nContoh: ${m.prefix}${m.command} Halo`);
    }

    let teksVertikal = '';
    for (let i = 0; i < text.length; i++) {
      teksVertikal += text[i] + '\n';
    }

    await conn.sendMessage(m.chat, { text: teksVertikal.trimEnd() }, { quoted: m });
  },
};
