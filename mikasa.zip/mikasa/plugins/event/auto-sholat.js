const moment = require('moment-timezone');
const axios = require('axios');
const { fromBuffer } = require('file-type');

let lastReminder = {}; // userID: jam terakhir diingatkan

module.exports = {
   start: async (m, { conn }) => {
      const userId = m.sender;

      // Tambah user ke daftar pengingat
      if (!lastReminder[userId]) {
         lastReminder[userId] = '00:00'; // default waktu kosong
      }

      // Mulai interval satu kali saja
      if (!global.sholatReminderStarted) {
         setInterval(async () => {
            const now = moment().tz('Asia/Jakarta');
            const jam = now.format('HH:mm');

            const jadwal = {
               subuh: '04:40',
               dzuhur: '12:00',
               ashar: '15:20',
               maghrib: '18:00',
               isya: '19:10'
            };

            for (let [waktu, target] of Object.entries(jadwal)) {
               if (jam === target) {
                  for (let id in lastReminder) {
                     if (lastReminder[id] !== jam) {
                        const pesan = `Waktunya sholat *${waktu.toUpperCase()}*, jangan lupa wudhu dan niat ya!`;

                        // Gambar thumbnail
                        const imgURL = 'https://i.ibb.co/YQmSfCJ/sholat-icon.png';
                        const res = await axios.get(imgURL, { responseType: 'arraybuffer' });
                        const buffer = res.data;
                        const type = await fromBuffer(buffer);

                        await conn.sendMessage(id, {
                           image: buffer,
                           mimetype: type.mime,
                           caption: pesan
                        });

                        lastReminder[id] = jam;
                     }
                  }
               }
            }
         }, 60 * 1000); // cek tiap menit

         global.sholatReminderStarted = true;
      }
   }
};