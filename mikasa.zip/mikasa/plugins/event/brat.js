exports.default = {
   names: ['Main Menu'],
   tags: ['brat'],
   command: ['brat'],
   start: async (m, {
      conn,
      text,
      prefix,
      command,
      Format
   }) => {
      text = text || 'contoh'
     // m.reply('fitur ini dalah tahap pengembangan jadi mohon maaf jika image yang anda inginkan tidak sesuai⚠️')
      let caption = `Hay Ka @${m.sender.split('@')[0]} pilihlah sesuai yang anda mau😄`
      let media = cover 
      let button = [
         ['gambar', '.b  ' + text], 
         ['video', '.bv  ' + text]
      ]
      conn.sendButton(m.chat, caption, media, m, button)
   }
}