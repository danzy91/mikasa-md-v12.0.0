const toxic = ['kontol', 'ktl', 'memek', 'mmk', 'ngentot', 'ngntt', 'anjing', 'anjg', 'ajg', 'babi', 'jembut', 'jmbt', 'goblok', 'gblk', 'tolol', 'tlol'];
const agree = ['lanjut', 'loli'];

module.exports = {
   start: async (m, { conn, budy }) => {
      try {
         const isToxic = toxic.some(word => budy.toLowerCase().includes(word));
         const isAgree = agree.some(v => budy.toLowerCase().includes(v));

         if ((!m.isGroup || db.chats[m.chat].antiToxic) && isToxic && !isAgree && !m.fromMe && !m.isBaileys) {
            // Hapus pesan
            await conn.sendMessage(m.chat, { delete: m.key });

            // Kirim balasan dengan thumbnail & teks di kanan
            await conn.sendMessage(m.chat, {
               text: 'kata toxic ga di dukung bre, sory gw hapus 🤓',
               contextInfo: {
                  externalAdReply: {
                     title: "jangan berkata kasar lagi yaa ☺", // teks kanan atas
                     body: "Toxic Detected System", // teks kanan bawah
                     thumbnailUrl: "https://i.imgur.com/nrN6xsu.jpeg", // thumbnail kiri
                     sourceUrl: "https://whatsapp.com/channel/0029Vb5RBpCLSmbTNvFPGH2B", // kalau diklik
                     mediaType: 1,
                     renderLargerThumbnail: false,
                     showAdAttribution: true
                  }
               }
            }, { quoted: m });
         }
      } catch (e) {
         console.error('Error anti-toxic:', e);
         return false;
      }
   }
}