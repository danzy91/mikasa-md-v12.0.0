module.exports = {
   start: async (m, { 
      budy
   }) => {
      if (word(budy, 'tes')) {
         return m.reply('tas tes tas tes hadehh \n MENDOKUSAI !!!');
      }
   }   
}