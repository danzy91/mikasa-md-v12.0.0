module.exports = {
   start: async (m, { 
      budy
   }) => {
      if (word(budy, "🗿")) {
         return m.reply("Lu ngapain emot muka lu sendiri")
         //return m.react("💩") 
      }
   }   
}