module.exports = {
    names: ['Auto Reminder'],
    tags: ['auto', 'islam', 'reminder'],
    async handler(m, { conn }) {
        if (!m.fromMe) return; // Hanya aktif untuk bot sendiri (mencegah spam)

        const now = new Date();
        const hour = now.getHours();
        const minute = now.getMinutes();

        let namaSholat = '';

        // Perkiraan waktu sholat Bekasi (sesuaikan dengan waktu terkini)
        const perkiraanWaktu = {
            subuh: { jam: 4, menit: 30 },
            dzuhur: { jam: 12, menit: 0 },
            ashar: { jam: 15, menit: 30 },
            maghrib: { jam: 18, menit: 0 },
            isya: { jam: 19, menit: 15 },
        };

        // Fungsi untuk mengirim pengingat
        const kirimPengingat = async (nama) => {
            const pesanPengingat = `
🔔 *WAKTU SHOLAT TELAH TIBA!* 🔔

Saat ini menunjukkan pukul *${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')} WIB*.
Waktunya untuk menunaikan ibadah sholat *@${m.sender.split('@')[0]}.
Semoga Allah menerima amal ibadah kita. 🙏
`;
            await conn.sendMessage(m.chat, { text: pesanPengingat }); // Kirim ke chat asal (m.chat)
        };

        // Pengecekan waktu dan pengiriman pengingat
        if (hour === perkiraanWaktu.subuh.jam && minute === perkiraanWaktu.subuh.menit) {
            namaSholat = 'Subuh';
            kirimPengingat(namaSholat);
        } else if (hour === perkiraanWaktu.dzuhur.jam && minute === perkiraanWaktu.dzuhur.menit) {
            namaSholat = 'Dzuhur';
            kirimPengingat(namaSholat);
        } else if (hour === perkiraanWaktu.ashar.jam && minute === perkiraanWaktu.ashar.menit) {
            namaSholat = 'Ashar';
            kirimPengingat(namaSholat);
        } else if (hour === perkiraanWaktu.maghrib.jam && minute === perkiraanWaktu.maghrib.menit) {
            namaSholat = 'Maghrib';
            kirimPengingat(namaSholat);
        } else if (hour === perkiraanWaktu.isya.jam && minute === perkiraanWaktu.isya.menit) {
            namaSholat = 'Isya';
            kirimPengingat(namaSholat);
        }
    }
};
