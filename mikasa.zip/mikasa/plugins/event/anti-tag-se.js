module.exports = {
   start: async (m, {
      conn,
      budy,
      User,
      Format
   }) => {
      // Deteksi ID Creator
      const isCreator = [conn.user?.jid, global.owner].flat().includes(m.sender);

      // Deteksi apakah bot admin di grup
      const groupMetadata = m.isGroup ? await conn.groupMetadata(m.chat) : {};
      const participants = m.isGroup ? groupMetadata.participants : [];
      const botNumber = conn.user?.jid || conn.user?.id;
      const bot = m.isGroup ? participants.find(p => p.id === botNumber) : null;
      const isBotAdmin = bot?.admin === 'admin' || bot?.admin === 'superadmin';

      // Deteksi apakah user admin grup
      const sender = m.sender;
      const user = m.isGroup ? participants.find(p => p.id === sender) : null;
      const isAdmin = user?.admin === 'admin' || user?.admin === 'superadmin';

      // Anti Tag WhatsApp Status
      if (
         !m.key.fromMe &&
         db.groups[m.chat]?.antitagsw &&
         !isCreator &&
         m.isGroup &&
         isBotAdmin &&
         !isAdmin
      ) {
         if (
            m.type === 'groupStatusMentionMessage' ||
            m.message?.groupStatusMentionMessage ||
            m.message?.protocolMessage?.type === 25 ||
            (Object.keys(m.message).length === 1 && Object.keys(m.message)[0] === 'messageContextInfo')
         ) {
            if (!db.groups[m.chat].tagsw) db.groups[m.chat].tagsw = {};
            if (!db.groups[m.chat].tagsw[m.sender]) {
               db.groups[m.chat].tagsw[m.sender] = 1;
               await m.reply(`Grup ini terdeteksi ditandai dalam Status WhatsApp\n@${m.sender.split('@')[0]}, mohon untuk tidak menandai grup dalam status WhatsApp\nPeringatan ${db.groups[m.chat].tagsw[m.sender]}/5, akan dikick sewaktu waktu❗`);
            } else if (db.groups[m.chat].tagsw[m.sender] >= 5) {
               await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove').catch((err) => m.reply('Gagal!'));
               await m.reply(`@${m.sender.split("@")[0]} telah dikeluarkan dari grup\nKarena menandai grup dalam status WhatsApp sebanyak 5x`);
               delete db.groups[m.chat].tagsw[m.sender];
            } else {
               db.groups[m.chat].tagsw[m.sender] += 1;
               await m.reply(`Grup ini terdeteksi ditandai dalam Status WhatsApp\n@${m.sender.split('@')[0]}, mohon untuk tidak menandai grup dalam status WhatsApp\nPeringatan ${db.groups[m.chat].tagsw[m.sender]}/5, akan dikick sewaktu waktu❗`);
            }
         }
      }
   }
};