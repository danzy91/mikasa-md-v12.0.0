exports.default = {
   start: async (m, {
      conn,
      budy,
      User,
      Format
   }) => {
       if (!m.isGroup || m.fromMe || !budy) {
           return;
       }

       const tagStatusRegex = /(?:^|\s)@status(?:\s|$)/i;

       if (tagStatusRegex.test(budy)) {
           console.log(`Mendeteksi tag status oleh ${m.sender.split('@')[0]} di ${m.chat}`);

           const responseText = "Maaf, tag status tidak diizinkan di grup ini.";
           const senderNumber = m.sender;

           const groupMetadata = await conn.groupMetadata(m.chat);
           const isBotAdmin = groupMetadata.participants.some(p => p.id === conn.user.jid && p.admin !== null);

           if (isBotAdmin) {
               try {
                   await conn.sendMessage(m.chat, {
                       text: responseText
                   }, {
                       quoted: m
                   });
                   // Opsi: Hapus pesan (perlu izin admin bot)
                   // await conn.sendMessage(m.chat, { delete: m.key });
               } catch (error) {
                   console.error("Gagal membalas/menghapus pesan tag status:", error);
               }
           } else {
               console.warn("Bot bukan admin, tidak dapat membalas/menghapus pesan tag status.");
           }
       }
   }
};
