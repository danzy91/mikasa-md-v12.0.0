exports.default = {
   names: ['Main Menu'],
   tags: ['menu anime'],
   command: ['manime','menu anime'],
   start: async (m, {
      conn,
      text,
      prefix,
      command,
      Format
   }) => {
      text = text || 'contoh'
      m.react('📝')
      //m.reply('fitur ini dalah tahap pengembangan jadi mohon maaf jika image yang anda inginkan tidak sesuai⚠️')
      let caption = `Hay Ka @${m.sender.split('@')[0]} berikut adalah anime yang bisa anda cari😄`
      let media = cover 
      let button = [
         ['loli', '.gimage anime loli'], 
         ['nekano', '.gimage anime nekano'], 
         ['blue archive', '.gimage anime blue archive'],
         ['oshi no ko', '.gimage karakter anime oshi no ko'],
         ['aot', '.gimage karakter anime atack on titan'],
         ['anime cowo', '.gimage karakter anime cewe'],
         ['anime cewek', '.gimage karakter anime cowo'],
         ['majo no tabi tabi', '.gimage karakter anime majo no tabi tabi'],
      ]
      conn.sendButton(m.chat, caption, media, m, button)
   }
}