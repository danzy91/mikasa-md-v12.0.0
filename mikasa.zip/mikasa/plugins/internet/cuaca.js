const axios = require('axios');

exports.default = {
  names: ['Tools'],
  tags: ['cuaca'],
  command: ['cuaca'],
  start: async (m, {
    conn,
    text,
    prefix,
    command,
    User,
    Format
  }) => {
    try {
      if (!text) return m.reply(`Contoh: ${prefix}${command} jakarta`);

      const lokasi = text.trim();
      const encodedLokasi = encodeURIComponent(lokasi);
      const geoUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodedLokasi}&count=1&language=id&format=json`;
      const geoRes = await axios.get(geoUrl);
      const geoData = geoRes.data;

      if (!geoData.results || geoData.results.length === 0) {
        return m.reply(`Lokasi "${lokasi}" tidak ditemukan.`);
      }

      const { latitude, longitude, name, country, admin1 } = geoData.results[0];
      const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current_weather=true&timezone=auto`;
      const weatherRes = await axios.get(weatherUrl);
      const weatherData = weatherRes.data;

      const cuaca = weatherData.current_weather;
      const suhu = cuaca.temperature;
      const angin = cuaca.windspeed;
      const kodeCuaca = cuaca.weathercode;

      const weatherCodes = {
        0: 'Cerah',
        1: 'Sebagian Berawan',
        2: 'Berawan',
        3: 'Mendung',
        45: 'Kabut',
        48: 'Kabut Beku',
        51: 'Gerimis Ringan',
        53: 'Gerimis Sedang',
        55: 'Gerimis Lebat',
        56: 'Gerimis Beku Ringan',
        57: 'Gerimis Beku Lebat',
        61: 'Hujan Ringan',
        63: 'Hujan Sedang',
        65: 'Hujan Lebat',
        66: 'Hujan Beku Ringan',
        67: 'Hujan Beku Lebat',
        71: 'Salju Ringan',
        73: 'Salju Sedang',
        75: 'Salju Lebat',
        77: 'Butiran Salju',
        80: 'Hujan Ringan',
        81: 'Hujan Sedang',
        82: 'Hujan Lebat',
        85: 'Salju Ringan',
        86: 'Salju Lebat',
        95: 'Badai Petir',
        96: 'Petir + Hujan Es Ringan',
        99: 'Petir + Hujan Es Lebat'
      };

      const kondisi = weatherCodes[kodeCuaca] || 'Tidak diketahui';
      const lokasiLengkap = `${name}${admin1 ? ', ' + admin1 : ''}, ${country}`;
      const previewLink = `https://open-meteo.com/en/weather/${encodedLokasi}`;
      const thumbnailUrl = `https://raw.githubusercontent.com/iamsahebgit/weather-icons/main/png/${kodeCuaca}.png`;

      const header = 'WhatsApp ✓• Status';
      const waktu = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });

      const isi = `
pesan nya → .cuaca ${lokasi}

╭───〔 *Cuaca Terkini* 〕───╮
│  Lokasi  : ${lokasiLengkap}
├─────────────────────────
│  ☁️ Kondisi : *${kondisi}*
│  🌡️ Suhu    : *${suhu}°C*
│  💨 Angin   : *${angin} km/jam*
╰─────────────────────────╯

🕒 Update: *${waktu} WIB*
`.trim();

      await conn.sendMessage(m.chat, {
        text: `${header}\n\n${isi}`,
        contextInfo: {
          forwardingScore: 999,
          isForwarded: true,
          externalAdReply: {
            title: `Cuaca Hari Ini`,
            body: lokasiLengkap,
            thumbnailUrl: thumbnailUrl,
            sourceUrl: previewLink,
            mediaType: 1,
            renderLargerThumbnail: false,
            showAdAttribution: false
          }
        }
      }, { quoted: m });

    } catch (err) {
      console.error(err);
      m.reply('Gagal mengambil data cuaca. Coba lagi dengan lokasi yang lebih spesifik.');
    }
  },
  limit: false
};