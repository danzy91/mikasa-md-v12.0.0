const axios = require('axios')

exports.default = {
  names: ['Satusehat'],
  tags: ['kesehatan', 'satusehat'],
  command: ['satusehat'],
  start: async (m, { conn, text, prefix, command, User, Format }) => {
    try {
      if (!text) return m.reply(`Gunakan:\n${prefix + command} faskes <nama kota>\nContoh: ${prefix + command} faskes Bandung`)
      
      const [tipe, ...params] = text.split(' ')
      const query = params.join(' ')

      if (tipe === 'faskes') {
        const res = await axios.get(`https://api-satusehat.kemkes.go.id/fhir-r4/Organization?name=${encodeURIComponent(query)}`)
        const orgs = res.data.entry

        if (!orgs || orgs.length === 0) return m.reply('Fasilitas kesehatan tidak ditemukan.')

        for (let i = 0; i < Math.min(orgs.length, 5); i++) {
          const org = orgs[i].resource
          const teks = `*${org.name}*\nID: ${org.id}`

          await conn.sendMessage(m.chat, {
            image: { url: 'https://cdn-icons-png.flaticon.com/512/3774/3774299.png' }, // thumbnail kecil ikon rumah sakit
            caption: teks
          }, { quoted: m })
        }
      } else {
        m.reply(`Tipe data "${tipe}" belum tersedia.\nGunakan: ${prefix + command} faskes <nama kota>`)
      }
    } catch (e) {
      console.error(e)
      m.reply('Terjadi kesalahan saat mengambil data.')
    }
  },
  limit: false
}