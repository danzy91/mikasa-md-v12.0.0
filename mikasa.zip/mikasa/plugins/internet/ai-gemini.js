exports.default = {
   names: ['Internet'],
   tags: ['gemini', 'gem'],
   command: ['gemini', 'gem', 'aig'],
   start: async (m, {
      conn,
      text,
      prefix,
      command,
      Format
   }) => {
      if (!text) return m.reply(`ketiklah apa yang ingin kamu tanya oleh gemini? \n contoh ${prefix+command} apa kabar?`);
      m.react('👋');
      const data = await Format.Scraper.gemini(text);
      //conn.adReply(m.chat, loading, cover, m).then(() =>{
         conn.adReply(m.chat, data, cover, m);
      //});
   },
  limit: false
}