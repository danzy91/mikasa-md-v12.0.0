exports.default = {
   names: ['Internet'],
   tags: ['ai', 'chatgpt', 'openai'],
   command: ['ai', 'chatgpt', 'openai'],
   start: async (m, {
      conn,
      text,
      prefix,
      command,
      Format
   }) => {
      if (!text) m.reply(`ai gpt di alihkan ke .gemini / .gem  \n \n> di alihkan karena ada kesalahan di function TERIMAKASIH 🙏`);
       m.react('❌');
      //const data = await JSON_URL('https://apizell.web.id/ai/blackbox?prompt='+text);
      //conn.adReply(m.chat, loading, cover, m).then(() => {
         //conn.adReply(m.chat, data.result.replace(/\*/g,""), cover, m); 
      //})
   },
   //limit: true
} 